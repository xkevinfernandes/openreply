# Branding: the one home

Kevin, 2026-10-30: *"let's put branding in 1 place … we essentially have 2 types of brand"*.
There are exactly **two brands**, and both live here. Everything else is a **template** that applies one of them.

| brand | folder | is for | reference build (the live thing) |
|---|---|---|---|
| **The website brand** | [`website/`](website/README.md) + `tokens.css` | everything public: claudepreneur.com, offer pages, and the brand that reels, carousels and Canva apply | `Sales_Pages/components/site-next/` on `main` (served at claudepreneur.com `/`) |
| **The app brand** (the reel look) | [`apps/`](apps/README.md) + `tokens.css` | Kevin's own apps: the client portal, DataOS/ContentOS, DM OS, dashboards, any custom tool | `DataOS` `dashboard/public/theme.css` on `main` |

If a file anywhere else states a brand colour, font or rule that disagrees with one of these, **that file is the bug**.
Other files point here, they never restate it.

## Templates: not brands, they stay where they are

A template applies a brand to one medium and may differ slightly from the website (Kevin: *"the way we do it on
carousels and videos … can be slightly different"*). They keep their own homes:

| templates | home |
|---|---|
| sales pages (long-form offer pages) | `Sales_Pages/DESIGN.md` and its page templates (unchanged) |
| video: reels, YouTube cards, SPLIT boards, captions | `Production/engines/hyperframes/studio/assets/brand.css` (+ Resolve templates) |
| carousels, stills | the review room's carousel editor (`Production/formats/carousel/`) |

## Retired, kept only as pointers

- `Kaito/00-shared/clients/claudepreneur/visual-identity.md` and its `tokens.css` → moved to `website/` on 2026-10-30.
- `Landing Page/` (the dark "noir magazine" homepage) no longer serves claudepreneur.com; its design notes are history.
- `Sales_Pages/app/site/` is the older /site redesign, superseded by `components/site-next/`.
- `apps/_previous-2026-10-21/` is the app look before the reel look.

## Using it in an app (instead of copying the numbers)

This folder is a package, `@claudepreneur/brand`, on GitHub at `xkevinfernandes/branding`.
An app installs it once and imports the file, so a brand change is one edit here plus a version bump there:

```bash
npm install github:xkevinfernandes/branding#v0.7.0
```

```css
@import "@claudepreneur/brand/apps.css";        /* Kevin's apps: portal, DataOS, DM OS, dashboards, editors */
@import "@claudepreneur/brand/components.css";  /* the shared app components (cp- classes), after apps.css */
@import "@claudepreneur/brand/website.css";     /* public pages only */
```

`apps/tokens.css` also gives plain elements (`body`, `h1`, `input`, `button`) a base look, but every one of those
rules sits in `:where()`, so it has no specificity and an app's own styles always win.

## The shared app components

One small set of building blocks for every app on the app brand (not the website), in two layers:

1. **`components.css`**: plain CSS classes, all prefixed `cp-`, on the tokens. Works anywhere: Next + Tailwind 4
   (the portal), Next + Tailwind 3 (Sales_Pages), plain HTML (DataOS's dashboard). Nothing changes on a page
   until it uses a `cp-` class.
2. **`@claudepreneur/brand/react`**: thin React 19 components that only write that markup, the classes and the
   accessibility. Shipped built (`dist/`, plain JS + `.d.ts`), so an app needs no transpile step. React is an
   optional peer dependency; a plain-HTML app ignores it.

```tsx
import { PageHeader, Button, StatRow, StatTile, Card, List, ListItem } from "@claudepreneur/brand/react";

<PageHeader title="Good morning, Maya" subtitle="Tuesday 10 November" actions={<Button>Add client</Button>} />
<StatRow label="Today at a glance">
  <StatTile label="Waiting on you" value="4" foot="oldest 3d" feature />
  <StatTile label="Gone quiet" value="2" foot="not on the portal in 7+ days" footTone="bad" />
</StatRow>
```

| component | classes | notes |
|---|---|---|
| `PageHeader` | `cp-page-header` (`has-slots`), `cp-page-title`, `cp-page-sub`, `cp-page-actions`, `cp-page-back`, `cp-back`, `cp-page-title-row`, `cp-page-meta` | h1 24/500, the portal's type. v0.7: `back`, `meta`, actions on the h1 row at 38 (`alignActions`), stacked under the subtitle on a phone |
| `Button` (`primary` / `secondary` / `text` / `danger`, `sm`, `loading`), `buttonClassName()` for links | `cp-btn`, `cp-btn-primary`, `cp-btn-text` (`is-ink`), `cp-btn-danger`, `cp-btn-sm`, `is-loading` | press 0.97; v0.7: disabled = well + muted words (not a faded slab) |
| `SegmentedSwitch` | `cp-seg`, `cp-seg-item` | radiogroup, arrow keys + Home/End; well track inside a card; `compact` (v0.6, also on `Tabs`): smaller, and no 44px rows on a phone |
| `StatTile`, `StatRow` | `cp-stats`, `cp-stat` (`is-feature`), `cp-stat-label/-num/-foot` | one ink feature tile per row |
| `Card`, `List`, `ListItem` | `cp-card`, `cp-card-head`, `cp-card-title`, `cp-card-more`, `cp-list`, `cp-list-item` … | parts 12px apart, rows 12px with hairlines |
| `Table`, `Who`, `TwoLines` | `cp-table`, `cp-table-row`, `cp-table-head`, `cp-cell` (`is-num`, `is-phone-hidden`), `cp-who` … | columns as grid tracks; list rows on a phone |
| `Pill` (`good` / `neutral` / `bad` / `warn`) | `cp-pill`, `cp-pill-good/-bad/-warn` | |
| `Avatar`, `Thumb`, `initials()` | `cp-avatar`, `cp-thumb` | initials = the portal's rule: first + last word, a leading Coach/Dr/Prof/Mr/Mrs/Ms/Mx dropped ("Coach Maya Reyes" → MR); no name → "·"; thumb 44×78 radius 8 |
| `Input`, `Textarea`, `NativeSelect` | `cp-field`, `cp-field-label`, `cp-input`, `cp-select` | `NativeSelect` is the OS menu; only where it must be native |
| `Select` | `cp-select-trigger`, `cp-pop`, `cp-listbox`, `cp-option` (`-label/-desc/-meta/-check`) | custom list (Astryx's Select popover on our tokens); combobox/listbox ARIA; ↑↓ Home End PgUp PgDn, Enter/Space, Esc, type-ahead; outside press closes; flips and fits the viewport; top layer, so it works inside a Dialog; bottom sheet ≤640px; `name` adds a hidden input |
| `Combobox` | the same + `cp-pop-search` | the Select with a search box for long lists (timezones, clients, Kit tags, Slack channels); groups, meta, keywords |
| `MultiCombobox` | `cp-multi`, `cp-multi-trigger`, `cp-chips`, `cp-chip`, `cp-chip-x`, `cp-option.is-multi`, `cp-option-box`, `cp-multi-foot` | the multi-pick: several values as removable chips in the field, a search box, the list stays open while you pick (round tick per row), `aria-multiselectable`; Backspace removes the last chip, ← steps onto the chips (← → move, Backspace/Delete removes one); adds/removals announced; `max`, `renderChip`, `name` = one hidden input per value; phone sheet with Done. Kit tags, countries |
| `MenuButton` | `cp-pop`, `cp-menu`, `cp-menu-item` (`is-danger`, `aria-checked`, `has-desc`, `has-sub`), `cp-menu-desc`, `cp-submenu`, `cp-pop-sep`, `cp-pop-label` | actions and filters; menu ARIA, roving focus, wraps, type-ahead, Esc/Tab return focus; filter items keep it open. v0.6: `description` (a 12px help line under the label) and `items` (a submenu beside the row: → / Enter opens, ← / Esc back; a second sheet with Back on a phone; `cp-menu.js` does it with `data-cp-submenu`) |
| `DateRange` | `cp-range-*`, `cp-cal-*` | presets + calendar (2 months wide, 1 on a phone), range band, arrows/PgUp/PgDn, Apply; dates are local `YYYY-MM-DD`. `presets="pills"` (v0.6): 7d / 30d / 90d / All inline as a switch + a Custom pill that opens the calendar (`pillPresets`, `compact`) |
| `DatePicker` (v0.6) | `cp-date-trigger`, `cp-date-pop`, `cp-cal-*` | one date: an input-look field opening the DateRange's calendar (one month); arrows/PgUp/PgDn/Home/End, Enter picks, Esc; Today / Clear; `min`/`max` (keys stop there); `name` = hidden input; `labelPlacement`, `controlSize`. Plain HTML: `cp-date.js` upgrades `<input type="date" class="cp-date">` |
| `Field` (v0.6) | `cp-field` (`is-inline`) | a label + any control + hint; `labelPlacement="inline"` = label left, control right (stacks on a phone), on Input/Textarea/NativeSelect/Select/Combobox/MultiCombobox/DatePicker too |
| `ToastProvider`, `useToast` | `cp-toasts` (`data-position`), `cp-toast` (`is-good/-bad`), `cp-toast-action` | the portal's toast: ink chip radius 12, 3 at most, auto-dismiss (paused on hover/focus), aria-live, bad = alert, above dialogs. v0.6: `position` (default **bottom-center**; v0.5 was bottom-right), `offset` px or `--cp-toast-offset`, `above=".save-bar"` stacks it over a sticky bar while that bar is on screen |
| `ConfirmDialog`, `useConfirm` | `cp-dialog.is-confirm`, `cp-dialog-desc` | `await confirm()` / `await prompt()` instead of window.confirm/prompt; `danger` = red button, Cancel focused |
| `Toggle` | `cp-toggle`, `cp-switch` | native checkbox with role="switch" (submits with a form); ink when on |
| `ConnectionsGrid`, `ConnectionCard`, `ConnectDialog`, `ConnectionDetail` (v0.8) | `cp-conn-*` | the services an app talks to: connected first, then the catalogue with category pills; connect = scopes listed first, then the provider's sign-in or a key field that never shows the key back; manage = as / by / when, Check now, last four, access, activity, a real Disconnect. Monochrome built-in logos (`ServiceLogo`, `SERVICE_LOGOS`). No prop takes a secret. Plain HTML: `cp-connections.js`. Rules apps must follow: `apps/README.md` → Connections |
| `IconButton` | `cp-icon-btn` (`-sm`, `is-well`, `is-ink`, `is-danger`) | 36/32px round, label = aria-label + tooltip; 44px hit area to a finger |
| `Button` `danger`, `loading` | `cp-btn-danger`, `cp-btn.is-loading` | loading keeps the label and width, dims and breathes; no spinner |
| `Tabs` | `cp-tabs`, `cp-tab`, `cp-tab-panel` | the switch's look with tab semantics (arrows, Home/End); link mode with `href` |
| `Sidebar`, `AppShell` | `cp-shell`, `cp-main`, `cp-side-*` | the portal's reel-sidebar: floating card, ink pill, drill-in sections, group labels, 64px slim strip with grow-out pill, frosted phone header with a swipeable pill row; pass `linkComponent={Link}`. v0.6: `group` on a section (top-level headings), `labelStyle="plain"`, `width` (e.g. 240; long names … + tooltip), `header` / `footer` slots, `themeSwitch="menu" \| "foot" \| "none"`, `defaultSlim` + `onSlimChange` (cookie), `dot` / `extra` per row |
| `Icon` | — | the brand's line icons by name |
| `Dialog` | `cp-dialog`, `cp-dialog-body/-head/-title/-close/-foot` | native `<dialog>`: Esc, backdrop or × close; focus kept inside and returned; bottom sheet on a phone; `data-autofocus` picks the first focus |
| `EmptyState` | `cp-empty`, `cp-empty-title/-desc/-actions`, `cp-empty-inline` | v0.7 `variant="inline"`: one muted line, no well |
| `Skeleton`, `SkeletonLines` | `cp-skel`, `cp-skel-stack` | no spinners |
| `Checkbox`, `CheckRow` (v0.7) | `cp-checkbox`, `cp-check` (`is-row`), `cp-check-text/-hint/-detail`, `cp-checks` | the brand's own box (native input, CSS-drawn): ink + tick, `indeterminate` (or `aria-checked="mixed"` in HTML); CheckRow = box, title, hint, muted detail right |
| `DoneMark` (v0.7) | `cp-done` (`is-done`, `is-current`, `is-ink`, `cp-done-16/-24`) | display-only done state: ring / ink ring / good + tick; `label` for a screen reader |
| `TickList` (v0.7) | `cp-ticks` (`is-good`, `is-sm`), `li.is-off`, `cp-ticks-detail` | what a plan includes; off = muted dash |
| `RadioGroup` (v0.7) | `cp-radios` (`is-row`, `is-cards`), `cp-radio`, `cp-radio-opt`, `cp-radio-card`, `cp-radio-text/-desc` | native radios in a fieldset (arrow keys, form value); `variant="cards"` = option cards |
| `ProgressBar` (v0.7) | `cp-progress` (`is-thin`, `is-good`, `is-on-well`), `cp-progress-head/-track/-fill`, `--cp-progress` | role=progressbar; 10px (thin 4) |
| `Pill` `outline` / `dot`, `Tag`, `CountBadge`, `StatusDot` (v0.7) | `cp-pill is-outline/has-dot`, `cp-tag`, `cp-count` (`is-muted/-bad`), `cp-status-dot` (`is-good/-bad/-warn/-muted`) | status vs category vs count vs dot |
| `GroupLabel`, `SettingsRow`, `SettingsList`, `SaveBar`, `SettingStrip` (v0.7) | `cp-group-label`, `cp-setting` (`is-wide`), `cp-setting-text/-label/-help/-control`, `cp-settings`, `cp-savebar`, `cp-strip` | settings pages; `<ToastProvider above=".cp-savebar">` |
| `Disclosure` (v0.7) | `details.cp-disclosure` (`is-card`), `cp-disclosure-title/-meta/-body`, `cp-disclosures` | native details; chevron turns over |
| `TimePicker` (v0.7) | the Select's (+ `leading` icon) | times `step` min apart, `min`/`max`, `hour12`; HTML: a `cp-select` of times |
| `ColorField` (v0.7) | `cp-color`, `cp-color-btn/-chip/-pop/-sv/-thumb/-hue/-swatches/-swatch` | swatch + hex input; picker pop-up (square, hue, presets); React only |
| `FileButton`, `ImageField` (v0.7) | `cp-file-input`, `cp-image-field` (`is-round`, `is-wide`, `is-dragging`), `cp-image-preview/-text/-acts/-hint` | a Button that opens the chooser; preview + Upload / Replace / Remove, drop a file |
| `Page`, `Stack`, `SectionTitle` (v0.7) | `cp-page`, `cp-stack` (`is-tight`), `cp-section-title`, `cp-card is-list` | the spacing tokens (`--head-gap`, `--card-gap`, `--list-pad`, `--section-above/-below`) |

A titled list card (`Card` with a title + `List`) draws one hairline between the head and the first row
(the portal's "Needs you" card), so it reads the same everywhere.

**v0.8:** Connections (`ConnectionsGrid`, `ConnectionCard`, `ConnectDialog`, `ConnectionDetail`, built-in monochrome logos from
simple-icons, `cp-connections.js` for plain HTML) with the security contract in `apps/README.md`; an empty `ColorField` shows an empty
swatch and "None". Nothing removed. See MIGRATING.md.

**v0.7:** the pieces the portal inventory found missing: Checkbox / CheckRow, DoneMark, TickList, RadioGroup + option cards,
ProgressBar, Tag, CountBadge, StatusDot, outline / dot pills, GroupLabel, SettingsRow, SaveBar, SettingStrip, Disclosure, TimePicker,
ColorField, FileButton / ImageField, IconButton `xs` (28), EmptyState `inline`, PageHeader `back` / `meta` / aligned actions, a disabled
button look, and the spacing tokens + `cp-page` / `cp-stack` / `cp-section-title`. Checkbox, DoneMark, TickList, radios, ProgressBar and
Disclosure work as plain HTML with no script. Nothing removed. See MIGRATING.md.

**v0.6:** the options apps need to adopt the components without moving anything: Sidebar headings/width/slots/theme row/cookie slim,
DateRange pills mode, `DatePicker` (+ `cp-date.js`), menu help lines and submenus, toast position/offset/`above`, inline labels
(`Field`), `compact` switch, control-height tokens (`--control-h` 42 / `--control-h-sm` 38: Input, Select, DatePicker and Button now
match; buttons grew from ~38 to 42 and sm from ~34 to 38, set `--btn-h: 38px` / `--btn-h-sm: 34px` to keep the old), the dark neutral
pill now differs from the well, skeleton bars visible on stone. Nothing removed; v0.5 code keeps compiling. See MIGRATING.md.

**v0.5:** `MultiCombobox` (and `<select multiple class="cp-select">`), `SIDEBAR_PREPAINT` / `THEME_PREPAINT`,
Avatar initials match the portal, the Sidebar takes the old `nav-closed` class too, the toast is radius 12.
Migrating an app onto the package: [`MIGRATING.md`](MIGRATING.md).

**v0.4 breaking change:** `Select` is now the custom one and its `onChange` gets the value (`onChange={setBilling}`),
not an event. The v0.3 native select is `NativeSelect`.

### The dropdown rule (every app)

- **A form field** (pick one value) → `Select`.
- **A long list** (dozens or hundreds: timezones, clients, tags, channels) → `Combobox`.
- **Several values** (Kit tags, countries, channels) → `MultiCombobox` (`<select multiple class="cp-select">` in plain HTML).
- **Actions or filters** → `MenuButton`. Never put an action inside a select ("New subdomain…", "Delete").
- **Dates** → `DateRange` (a range) / `DatePicker` (one date, never a native date input). Yes/no → `Toggle`. Two to five views of one thing → `SegmentedSwitch` / `Tabs`.

### Plain HTML pages (DataOS, the editor rooms)

The CSS classes work on their own. Two small scripts add the behaviour (no build, no dependencies):

```html
<script src="…/apps/cp-select.js" defer></script>  <!-- upgrades every <select class="cp-select"> -->
<script src="…/apps/cp-menu.js" defer></script>    <!-- wires every <button data-cp-menu="id"> (+ data-cp-submenu rows) -->
<script src="…/apps/cp-date.js" defer></script>    <!-- upgrades every <input type="date" class="cp-date"> (v0.6) -->
<script src="…/apps/cp-connections.js" defer></script> <!-- Connections: logos, category pills, dialogs, the key field (v0.8) -->

<label for="tz">Timezone</label>
<select id="tz" name="tz" class="cp-select" data-search>…</select>   <!-- data-search = Combobox -->
<select id="tags" name="tags" class="cp-select" multiple data-placeholder="Choose tags">…</select>  <!-- the multi-pick -->
```

`cp-select.js` keeps the native `<select>` (hidden) as the form's value: the form still submits it, `change` and
`input` still fire on it, and setting `select.value` in code redraws the button. `<option data-meta>`,
`data-description`, `data-keywords` and `<optgroup label>` are read; selects added later are upgraded as they appear.
See the comment at the top of each file.

### Sidebar: set slim and theme before first paint

Slim is the class `cp-nav-closed` on `<html>`, remembered as `localStorage.nav = "closed"`; the theme is
`data-theme` from `localStorage.theme`. Both must be set before the first paint or the page flashes. In a
React app use the exported string (no "use client", so a server layout can import it):

```tsx
import { SIDEBAR_PREPAINT } from "@claudepreneur/brand/react";
<head><script dangerouslySetInnerHTML={{ __html: SIDEBAR_PREPAINT }} /></head>
```

In plain HTML, the same thing:

```html
<script>try{var d=document.documentElement,t=localStorage.getItem("theme");if(t==="light"||t==="dark")d.dataset.theme=t;if(localStorage.getItem("nav")==="closed")d.classList.add("cp-nav-closed","nav-closed")}catch(e){}</script>
```

**Migrating from the portal's own sidebar:** the portal's pre-paint adds `nav-closed` (no `cp-`). The shared
Sidebar accepts either during a migration: its CSS slims on `cp-nav-closed` *or* `nav-closed`, on mount it
adopts `nav-closed` as slim, and its toggle keeps both classes in step. The localStorage key (`nav`) is the
same. Once the app's old sidebar CSS is gone, swap the pre-paint for `SIDEBAR_PREPAINT` (it still sets both).
Theme only (no sidebar): `THEME_PREPAINT`.

Load Inter yourself (with its `opsz` axis, as next/font's `axes: ["opsz"]` does); the tokens name it, they don't ship it.
If the app self-hosts Inter under another name, point `--font` at it.

**Change a component:** edit `apps/components.css` and/or `react/*.tsx` here, run `npm run build` (writes `dist/`, which
is committed), bump `version` in `package.json`, commit, tag `vX.Y.Z`, push `main` and the tag, then bump the tag in each app.
Change a brand colour or rule: edit `apps/tokens.css` + `apps/README.md`, then the same bump and tag.

A few pieces were adapted from Astryx (MIT): see [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md). No app depends on Astryx.
