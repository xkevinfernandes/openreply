/* =============================================================================
   cp-date.js: the DatePicker for plain HTML pages (v0.6). No build, no
   dependencies. It upgrades every

     <label for="due">Due</label>
     <input type="date" id="due" name="due" class="cp-date" min="2026-01-01" value="2026-11-12">

   into a field that looks like the inputs and opens the DateRange's calendar
   (one month, Monday first). The <input> stays (hidden) as the form's value:
   the form still submits it, `required` still applies, and `input` + `change`
   fire on it when a day is picked. Setting input.value in code redraws the
   field (call cpDate.sync(input) if you set it without an event).
   Options as attributes: min, max, required, placeholder,
   data-clearable="false".

   Keyboard: Enter, Space or ↓ opens on the picked day (or today); the arrow
   keys move a day / a week, PageUp/PageDown a month, Home/End the week's
   ends, Enter or Space picks and closes, Esc closes; focus goes back to the
   field. A press outside closes it. Top layer (works in a <dialog>), flips
   above when needed, a bottom sheet on a phone. Inputs added later are
   upgraded as they appear.
   ============================================================================= */
(function () {
  "use strict";
  if (typeof window === "undefined" || window.cpDate) return;
  var SHEET = "(max-width: 640px)";
  var GAP = 6, EDGE = 8;
  var DOW = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
  var fmtField = new Intl.DateTimeFormat("en-GB", { day: "numeric", month: "short", year: "numeric" });
  var fmtMonth = new Intl.DateTimeFormat("en-GB", { month: "long", year: "numeric" });
  var fmtLong = new Intl.DateTimeFormat("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  var uid = 0;
  var openOne = null;

  var pad = function (n) { return String(n).padStart(2, "0"); };
  var iso = function (d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); };
  var parse = function (s) { var p = s.split("-").map(Number); return new Date(p[0], (p[1] || 1) - 1, p[2] || 1); };
  var valid = function (s) { return /^\d{4}-\d{2}-\d{2}$/.test(s || ""); };
  var addDays = function (d, n) { return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n); };
  var reduced = function () { return window.matchMedia("(prefers-reduced-motion: reduce)").matches; };
  var ICON_CAL = '<svg class="cp-range-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3.5" y="5" width="17" height="15" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/></svg>';
  var ICON_DOWN = '<svg class="cp-select-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
  var chev = function (d) { return '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + d + '"/></svg>'; };

  function shown(el) { try { return el.matches(":popover-open"); } catch (e) { return el.classList.contains("is-open"); } }
  function show(el) { if (el.showPopover) { if (!shown(el)) el.showPopover(); } else el.classList.add("is-open"); }
  function hide(el) { if (el.hidePopover) { if (shown(el)) el.hidePopover(); } else el.classList.remove("is-open"); }

  function place(btn, pop) {
    var r = btn.getBoundingClientRect();
    var vw = document.documentElement.clientWidth, vh = window.innerHeight;
    pop.style.maxHeight = "none";
    var h = pop.offsetHeight, w = pop.offsetWidth;
    var below = vh - r.bottom - GAP - EDGE, above = r.top - GAP - EDGE;
    var up = h > below && above > below;
    pop.style.maxHeight = Math.max(Math.min(h, up ? above : below), 0) + "px";
    h = pop.offsetHeight;
    pop.style.left = Math.round(Math.max(EDGE, Math.min(r.left, vw - w - EDGE))) + "px";
    pop.style.top = Math.round(Math.max(EDGE, up ? r.top - GAP - h : r.bottom + GAP)) + "px";
    pop.dataset.side = up ? "top" : "bottom";
    pop.dataset.align = "start";
  }

  function upgrade(input) {
    if (input.__cpDate) return;
    input.__cpDate = true;
    var n = ++uid;
    var id = input.id || (input.id = "cp-date-" + n);
    var labelEl = document.querySelector('label[for="' + id + '"]');
    if (labelEl && !labelEl.id) labelEl.id = id + "-label";
    var st = { input: input, view: null, focus: null };

    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "cp-input cp-select-trigger cp-date-trigger";
    if (input.classList.contains("is-on-well")) btn.classList.add("is-on-well");
    if (input.classList.contains("is-sm")) btn.classList.add("is-sm");
    btn.setAttribute("aria-haspopup", "dialog");
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("aria-controls", id + "-pop");
    if (input.required) btn.setAttribute("aria-required", "true");
    var valueSpan = document.createElement("span");
    valueSpan.className = "cp-select-value";
    valueSpan.id = id + "-value";
    btn.innerHTML = ICON_CAL;
    btn.appendChild(valueSpan);
    btn.insertAdjacentHTML("beforeend", ICON_DOWN);
    if (labelEl) {
      btn.setAttribute("aria-labelledby", labelEl.id + " " + valueSpan.id);
      labelEl.addEventListener("click", function (e) { e.preventDefault(); btn.focus(); });
    } else btn.setAttribute("aria-label", input.getAttribute("aria-label") || "Date");

    var pop = document.createElement("div");
    pop.id = id + "-pop";
    pop.className = "cp-pop cp-range-pop cp-date-pop";
    pop.setAttribute("popover", "manual");
    pop.setAttribute("role", "dialog");
    pop.setAttribute("aria-label", "Choose " + (labelEl ? labelEl.textContent.trim().toLowerCase() : "a date"));
    st.btn = btn; st.pop = pop;

    input.classList.add("cp-select-native");
    input.tabIndex = -1;
    input.setAttribute("aria-hidden", "true");
    input.after(btn, pop);

    sync(input);
    btn.addEventListener("click", function () { if (openOne === st) close(st, true); else open(st); });
    btn.addEventListener("keydown", function (e) {
      if (e.key === "ArrowDown") { e.preventDefault(); open(st); }
    });
    btn.disabled = input.disabled;
    input.addEventListener("input", function () { sync(input); });
    input.addEventListener("change", function () { sync(input); });

    pop.addEventListener("keydown", function (e) { onKey(st, e); });
    pop.addEventListener("click", function (e) {
      var t = e.target.closest && e.target.closest("button");
      if (!t || !pop.contains(t)) return;
      if (t.hasAttribute("data-day")) pick(st, t.getAttribute("data-day"));
      else if (t.dataset.act === "prev") { st.view = new Date(st.view.getFullYear(), st.view.getMonth() - 1, 1); render(st, false); }
      else if (t.dataset.act === "next") { st.view = new Date(st.view.getFullYear(), st.view.getMonth() + 1, 1); render(st, false); }
      else if (t.dataset.act === "today") pick(st, iso(new Date()));
      else if (t.dataset.act === "clear") pick(st, "");
    });
    input.__cpDateState = st;
  }

  function sync(input) {
    var st = input.__cpDateState || null;
    var btn = st ? st.btn : input.nextElementSibling;
    if (!btn) return;
    var span = btn.querySelector(".cp-select-value");
    var v = input.value;
    span.classList.toggle("is-placeholder", !valid(v));
    span.textContent = valid(v) ? fmtField.format(parse(v)) : input.getAttribute("placeholder") || "Pick a date";
    if (valid(v)) span.setAttribute("aria-label", fmtLong.format(parse(v)));
    else span.removeAttribute("aria-label");
    btn.disabled = input.disabled;
  }

  function off(st, d) {
    var min = st.input.min, max = st.input.max;
    return (valid(max) && d > max) || (valid(min) && d < min);
  }

  function render(st, focusDay) {
    var m = st.view;
    var today = iso(new Date());
    var v = st.input.value;
    var lead = (m.getDay() + 6) % 7;
    var days = new Date(m.getFullYear(), m.getMonth() + 1, 0).getDate();
    var ym = iso(m).slice(0, 7);
    var tabDay = st.focus && st.focus.slice(0, 7) === ym ? st.focus : ym + "-01";
    var titleId = st.input.id + "-title";
    var h = '<div class="cp-pop-head" aria-hidden="true">' + (st.btn.getAttribute("aria-labelledby") ? document.getElementById(st.btn.getAttribute("aria-labelledby").split(" ")[0]).textContent : "Date") + "</div>";
    h += '<div class="cp-range-months"><div class="cp-cal"><div class="cp-cal-head">';
    h += '<button type="button" class="cp-icon-btn cp-icon-btn-sm" data-act="prev" aria-label="Previous month" title="Previous month">' + chev("M15 6l-6 6 6 6") + "</button>";
    h += '<h3 class="cp-cal-title" id="' + titleId + '">' + fmtMonth.format(m) + "</h3>";
    h += '<button type="button" class="cp-icon-btn cp-icon-btn-sm" data-act="next" aria-label="Next month" title="Next month">' + chev("M9 6l6 6-6 6") + "</button></div>";
    h += '<div class="cp-cal-grid" aria-hidden="true">' + DOW.map(function (d) { return '<span class="cp-cal-dow">' + d + "</span>"; }).join("") + "</div>";
    h += '<div class="cp-cal-grid" role="grid" aria-labelledby="' + titleId + '">';
    var cells = [];
    for (var i = 0; i < lead; i++) cells.push(null);
    for (var d = 1; d <= days; d++) cells.push(ym + "-" + pad(d));
    while (cells.length % 7) cells.push(null);
    for (var w = 0; w < cells.length; w += 7) {
      h += '<div role="row" style="display:contents">';
      for (var c = w; c < w + 7; c++) {
        var day = cells[c];
        if (!day) { h += '<span role="gridcell" class="cp-cal-cell"></span>'; continue; }
        h += '<span role="gridcell" class="cp-cal-cell"><button type="button" class="cp-cal-day' + (day === today ? " is-today" : "") + '" data-day="' + day + '"' +
          ' tabindex="' + (day === tabDay ? 0 : -1) + '" aria-selected="' + (day === v) + '"' + (day === today ? ' aria-current="date"' : "") +
          ' aria-label="' + fmtLong.format(parse(day)) + '"' + (off(st, day) ? " disabled" : "") + ">" + Number(day.slice(8)) + "</button></span>";
      }
      h += "</div>";
    }
    h += "</div></div></div>";
    h += '<div class="cp-range-foot"><button type="button" class="cp-btn cp-btn-text cp-btn-sm" data-act="today"' + (off(st, today) ? " disabled" : "") + ">Today</button>";
    if (valid(v) && !st.input.required && st.input.getAttribute("data-clearable") !== "false")
      h += '<button type="button" class="cp-btn cp-btn-text cp-btn-sm" data-act="clear">Clear</button>';
    h += "</div>";
    st.pop.innerHTML = h;
    if (focusDay && st.focus) {
      var el = st.pop.querySelector('[data-day="' + st.focus + '"]');
      if (el) el.focus({ preventScroll: true });
    }
    if (!st.pop.classList.contains("is-sheet") && shown(st.pop)) place(st.btn, st.pop);
  }

  function onDown(e) {
    if (!openOne) return;
    var t = e.target, st = openOne;
    if (st.btn.contains(t)) return;
    if (t !== st.pop && st.pop.contains(t)) return;
    if (t === st.pop) {
      var r = st.pop.getBoundingClientRect();
      if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) return;
    }
    close(st, false);
  }
  function onMove() { if (openOne && !openOne.pop.classList.contains("is-sheet")) place(openOne.btn, openOne.pop); }
  function onScroll(e) { if (openOne && e.target instanceof Node && openOne.pop.contains(e.target)) return; onMove(); }

  function open(st) {
    if (st.btn.disabled) return;
    if (openOne) close(openOne, false);
    openOne = st;
    var v = st.input.value;
    var start = valid(v) ? v : iso(new Date());
    if (valid(st.input.max) && start > st.input.max) start = st.input.max;
    if (valid(st.input.min) && start < st.input.min) start = st.input.min;
    st.focus = start;
    st.view = new Date(parse(start).getFullYear(), parse(start).getMonth(), 1);
    var sheet = window.matchMedia(SHEET).matches;
    st.pop.classList.toggle("is-sheet", sheet);
    st.pop.classList.remove("is-closing");
    if (sheet) st.pop.style.top = st.pop.style.left = st.pop.style.maxHeight = "";
    show(st.pop);
    render(st, true);
    st.btn.setAttribute("aria-expanded", "true");
    document.addEventListener("pointerdown", onDown, true);
    window.addEventListener("resize", onMove);
    window.addEventListener("scroll", onScroll, true);
  }

  function close(st, focusBtn) {
    if (openOne !== st) return;
    openOne = null;
    st.btn.setAttribute("aria-expanded", "false");
    document.removeEventListener("pointerdown", onDown, true);
    window.removeEventListener("resize", onMove);
    window.removeEventListener("scroll", onScroll, true);
    if (focusBtn) st.btn.focus({ preventScroll: true });
    if (reduced()) return hide(st.pop);
    st.pop.classList.add("is-closing");
    setTimeout(function () {
      st.pop.classList.remove("is-closing");
      if (openOne !== st) hide(st.pop);
    }, st.pop.classList.contains("is-sheet") ? 200 : 120);
  }

  function pick(st, day) {
    if (day && off(st, day)) return;
    st.input.value = day;
    st.input.dispatchEvent(new Event("input", { bubbles: true }));
    st.input.dispatchEvent(new Event("change", { bubbles: true }));
    sync(st.input);
    close(st, true);
  }

  function onKey(st, e) {
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(st, true); return; }
    var t = e.target;
    if (!t.hasAttribute || !t.hasAttribute("data-day")) return;
    var d = parse(st.focus || t.getAttribute("data-day"));
    var dow = (d.getDay() + 6) % 7;
    var next = null;
    if (e.key === "ArrowRight") next = addDays(d, 1);
    else if (e.key === "ArrowLeft") next = addDays(d, -1);
    else if (e.key === "ArrowDown") next = addDays(d, 7);
    else if (e.key === "ArrowUp") next = addDays(d, -7);
    else if (e.key === "Home") next = addDays(d, -dow);
    else if (e.key === "End") next = addDays(d, 6 - dow);
    else if (e.key === "PageDown") next = new Date(d.getFullYear(), d.getMonth() + 1, d.getDate());
    else if (e.key === "PageUp") next = new Date(d.getFullYear(), d.getMonth() - 1, d.getDate());
    if (!next) return;
    e.preventDefault();
    var to = iso(next);
    if (valid(st.input.min) && to < st.input.min) to = st.input.min;
    if (valid(st.input.max) && to > st.input.max) to = st.input.max;
    next = parse(to);
    st.focus = to;
    st.view = new Date(next.getFullYear(), next.getMonth(), 1);
    render(st, true);
  }

  function upgradeAll(root) {
    (root || document).querySelectorAll("input.cp-date").forEach(upgrade);
  }
  window.cpDate = { upgrade: upgrade, upgradeAll: upgradeAll, sync: sync };
  function start() {
    upgradeAll(document);
    new MutationObserver(function (records) {
      for (var r = 0; r < records.length; r++) {
        var added = records[r].addedNodes;
        for (var n = 0; n < added.length; n++) {
          var node = added[n];
          if (node.nodeType === 1) {
            if (node.matches("input.cp-date")) upgrade(node);
            else if (node.querySelector) upgradeAll(node);
          }
        }
      }
    }).observe(document.documentElement, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
