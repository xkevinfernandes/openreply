# Moving an app onto @claudepreneur/brand

For an agent moving one of Kevin's apps (the portal, Sales_Pages dashboard, DataOS/ContentOS, DM OS, any tool)
onto the shared components. Read `README.md` (the component table) and `apps/README.md` (the rules) first.

## The scope rule (read this twice)

**UI only.** Swap how things look and behave as controls, nothing else:

- Never change how the app works: same data, same handlers, same validation, same routes, same server calls.
- Never change what is on a page or where it sits: same fields, same order, same copy, same layout.
- Delete nothing: no feature, field, page, option, or "unused" code you don't fully own. If an old CSS rule
  looks dead, leave it unless the component you just swapped in was its only user.
- One kind of piece per commit (all selects, then all confirms…), with typecheck + lint + a look at light,
  dark and 375px after each. If a swap needs a behaviour change to fit, stop and ask instead.

## Install

**React apps** (Next, Vite):

```bash
npm install github:xkevinfernandes/branding#v0.7.0
```

```css
/* global CSS, once, before the app's own styles */
@import "@claudepreneur/brand/apps.css";
@import "@claudepreneur/brand/components.css";
```

```tsx
import { Select, Combobox, MultiCombobox, MenuButton, ConfirmDialog, useConfirm,
         ToastProvider, useToast, Button, Skeleton } from "@claudepreneur/brand/react";
```

Wrap the app once in `<ToastProvider>` if it shows toasts. Load Inter with its `opsz` axis yourself.
For the theme (and the sidebar's slim state) before first paint, put `SIDEBAR_PREPAINT` (or `THEME_PREPAINT`)
in an inline `<script>` in the root layout's `<head>`; see "Sidebar" in the README.

**Plain-HTML apps** (DataOS dashboard, editor rooms) have no bundler, so they get copies of five files:

| file | what it does |
|---|---|
| `apps/tokens.css` | the colours, type, radii (light + dark) |
| `apps/components.css` | every `cp-` class |
| `apps/cp-select.js` | upgrades `<select class="cp-select">` into Select, `data-search` into Combobox, `multiple` into the multi-pick |
| `apps/cp-menu.js` | wires `<button data-cp-menu="id">` menus (submenus: `data-cp-submenu="id"` on a row) |
| `apps/cp-date.js` | upgrades `<input type="date" class="cp-date">` into the DatePicker (v0.6) |

v0.7's Checkbox, DoneMark, TickList, radios / option cards, ProgressBar and Disclosure need no script: just
the classes (markup in the comments of `components.css`). A time is a `<select class="cp-select">` of times.

Copy them into the app's static folder under a versioned folder, e.g. `public/brand/v0.5.0/`, and link them
(`<link rel="stylesheet">` for the CSS, `<script defer>` for the JS). To stay in sync: never edit the copies;
bump by copying from the package at the new tag
(`git -C ../branding checkout v0.X.Y && cp ../branding/apps/{tokens.css,components.css,cp-select.js,cp-menu.js,cp-date.js} public/brand/v0.X.Y/`),
point the links at the new folder, delete the old folder in the same commit, and note the tag in the app's README.
An app that already has `node_modules` can instead serve the files from `node_modules/@claudepreneur/brand/apps/`.

## Old pattern → component

| you find | use |
|---|---|
| `<select>` for one value in a form | `Select` (React) / `<select class="cp-select">` (HTML). `onChange` gets the value, not an event |
| a long `<select>` or a home-made searchable dropdown (timezones, clients, tags, channels) | `Combobox` / `<select class="cp-select" data-search>` |
| a multi-select, checkbox list in a dropdown, or chip picker (Kit tags, Sales_Pages `CountryPicker`) | `MultiCombobox` / `<select multiple class="cp-select">` |
| a "⋯" menu, a dropdown of actions, a filter dropdown | `MenuButton` / `cp-menu.js` |
| a date from/to pair or a period picker | `DateRange` (inline 7d/30d/90d/All pills: `presets="pills"`) |
| a native `<input type="date">` | `DatePicker` (`name` keeps the form value) / `<input type="date" class="cp-date">` + `cp-date.js` |
| `window.confirm(...)` | `const { confirm, prompt, dialog } = useConfirm();` render `{dialog}` once, then `if (await confirm({ title, danger: true, confirmLabel: "Delete" })) …` (`ConfirmDialog`) |
| `window.prompt(...)` | `const name = await prompt({ title, label, defaultValue })` from the same `useConfirm` (null = cancelled) |
| a spinner, "Loading…" text, or a blank area while loading | `Skeleton` / `SkeletonLines` in the shape of what's coming |
| a button that says "Saving…" or shows a spinner | `<Button loading>` (keeps its label and width) |
| a hand-made toast / "Saved!" banner | `useToast().toast("Saved")` |
| a checkbox styled as a switch | `Toggle` |
| an icon-only button | `IconButton` (needs a `label`) |
| tabs / a 2–5 way switch | `Tabs` / `SegmentedSwitch` |
| a modal | `Dialog` (native `<dialog>`) |
| the app's own sidebar | `Sidebar` + `AppShell`, `linkComponent={Link}` (see the README for `nav-closed` → `cp-nav-closed`) |
| page title row, stat tiles, cards, lists, tables, pills, avatars, empty states | `PageHeader`, `StatRow`/`StatTile`, `Card`/`List`, `Table`, `Pill`, `Avatar`, `EmptyState` |

## Keeping positions: the v0.6 options

v0.6 exists so a swap never moves anything. Use these to match what the app had:

| the app had | set |
|---|---|
| group headings in the sidebar (Funnels / Sell / CRM / Site / Settings), 12px muted, not uppercase | `group: "Sell"` on each section + `labelStyle="plain"` |
| a 240px sidebar | `width={240}` (long names end in … with a tooltip) |
| ⌘K search under the brand | `header={…}` (hidden on a phone) |
| Pause-all, a sends meter, a status line above the account | `footer={…}`; wrap wide-only bits in `className="cp-side-wide-only"` (and `cp-side-slim-only` for the slim strip) |
| the theme switch as its own row at the foot | `themeSwitch="foot"` (cycles Auto → Light → Dark; on a phone it stays in the account menu); `"none"` if the app has its own |
| slim state read from a cookie in the layout | `defaultSlim={cookie === "closed"}` + `onSlimChange={(s) => (document.cookie = …)}` (localStorage is written too) |
| a status dot or count on a nav row | `dot: "good" \| "bad" \| "warn" \| "neutral" \| true`, `badge: n`, or `extra={…}` |
| 7d / 30d / 90d / All pills next to a date | `<DateRange presets="pills" … />` (`pillPresets` to change them, `compact`) |
| a native date input in a form | `<DatePicker name="due" value onChange min max />` |
| a two-step menu ("Add" → "Form" → forms), help text under items | `items: […]` and `description` on a `MenuButton` entry |
| toasts bottom-centre (DM OS) | the default since v0.6 |
| toasts bottom-right (the portal) | `position="bottom-right"` (v0.5's spot) |
| a sticky save bar on phones | `<ToastProvider above=".save-bar">` (or `offset={64}` / `--cp-toast-offset`) |
| inline labels (portal Connections card) | `labelPlacement="inline"` on Input / Select / DatePicker…, or `<Field labelPlacement="inline">` round your own control; `--field-control-w` sets the control column (60%) |
| its own inputs/buttons next to shared ones | `height: var(--control-h)` (42) / `var(--control-h-sm)` (38) |
| short segmented switches on a phone | `compact` on SegmentedSwitch / Tabs (no 44px rows) |
| 38px buttons (v0.5's height) | `--btn-h: 38px; --btn-h-sm: 34px;` on `:root` (v0.6 buttons are 42 / 38 to match inputs) |

StatTile on a phone is padded 16px 18px (smaller than desktop), unchanged since v0.4.

## Upgrading v0.7 → v0.8

Nothing from v0.7 was removed or renamed. New: **Connections** (`ConnectionsGrid`, `ConnectionCard`,
`ConnectDialog`, `ConnectionDetail`, `ConnectionLogo`, `ServiceLogo`, `findServiceLogo`, `maskedKey`,
`SERVICE_LOGOS`) and `cp-connections.js` for plain HTML. One visible fix: an empty `ColorField` now shows
an empty swatch with a diagonal line and the placeholder "None" (it used to look like white / #000000).

Install: `"@claudepreneur/brand": "github:xkevinfernandes/branding#v0.8.0"`.

**If you tried the `connections-preview` branch** (it was never released), rename:

| preview | v0.8.0 |
|---|---|
| `keyLast4` | `last4` (only the last four are ever drawn, whatever you pass) |
| `ConnectDialog onContinue(c, key)` | `onContinue(c)` for OAuth, `onSubmitKey(c, key)` for a key |
| `ConnectDialog` scopes from `connection.scopes` | the required `scopes` prop (empty = it won't connect and says why) |
| `logo` = picture URL only | a built-in id (`"stripe"`), a URL, or your own node; empty = looked up from id/name, then the initial |
| "Synced 4 min ago" | "Checked 4 min ago" (`lastSync` is a live check) |
| — | `connectedAt`, `lastUsed`, `appLogo`, `error`, `checking`, `disconnecting` |

**Moving an app's connections page onto it** (one PR per app; see the rollout plan):

| you find | use |
|---|---|
| a stack of per-service cards / rows with an expanding panel (StripeCard, KitCard, `integrations.tsx` Row, `settings-board.tsx`) | `ConnectionsGrid` with one `Connection` per service |
| an inline "paste your key" field on the card | `ConnectDialog` (`method: "key"`), `onSubmitKey` POSTs it once |
| "Add to Slack" / "Connect Instagram" link | `ConnectDialog` (`method: "oauth"`), `onContinue` goes to your server's start route |
| the panel's own settings (Stripe mode, Kit tag mapping, Slack channel, calendar per setter) | `ConnectionDetail`'s `children` |
| a Test button | `onSyncNow` + `checking` ("Check now"); show the result as `lastSync` / `problem` |
| a key that only lives in Doppler / env | a card with `method: "managed"` (no Connect, no Disconnect) |
| a `secret`, `apiKey`, `token` in what the server sends the page | delete it from the response; send `last4` |

Before the UI swap, the server rules in `apps/README.md → Connections` must hold. The component can't
show a secret, but it can't stop a page from fetching one either.

## Upgrading v0.6 → v0.7

Nothing was removed or renamed; v0.6 code keeps compiling. Visible changes without touching code:
disabled buttons are the well with muted words (no longer a faded ink slab), and on a phone (≤860px)
`--card-pad` is 18 20 and `--tile-pad` 16 18 (cards and dialogs get 4px tighter). `PageHeader` only
changes when you pass a new slot.

**What replaces what** (the portal inventory's list; keep positions, per the scope rule):

| you find | use |
|---|---|
| a native `<input type="checkbox">` (accent-color) | `Checkbox` / `<input type="checkbox" class="cp-checkbox">` |
| a checkbox + title + muted detail row (capacity days, "who sees it", plans) | `CheckRow` in `<div className="cp-checks">` |
| check-box, phase-rail-tick, checkpoint-mark, mark-done-tick, cd-lesson-check, lesson-title-tick, ✅ | `DoneMark` (`done`, `current`, `size` 16/20/24) / `<span class="cp-done is-done">` |
| a "what's included" list with hand-drawn ticks | `TickList` / `<ul class="cp-ticks">` |
| `tab-head`, `r-head`, `cal-head`, `csx-page-head`, `cd-head`… | `PageHeader`; a back link → `back={<Link className="cp-back" href=…>Forms</Link>}`; a status pill next to the title or in the action row → `meta`; actions ≤ 2 buttons + ⋯, secondary → primary → ⋯ |
| `back-link` | `cp-back` in PageHeader's `back` |
| `cd-empty`, `digest-empty`, `sx-empty`, a centred "Nothing yet" in a list or table | `<EmptyState variant="inline" title="No calls yet." />` (a card of its own stays `EmptyState`) |
| `link-btn`, `pr-text-btn`, `ofr-add`, `cap-edit`, `cm-news-more`, `pr-archived-toggle` | `<Button variant="text">` (`className="is-ink"` for ink words) |
| `busy ? "Saving…" : label` | `<Button loading={busy}>label</Button>` |
| a neutral "Delete form" | `variant="danger"` (or a danger item in the ⋯ menu) |
| cm-act, cm-tool, rte-btn, ofr-x, question-row ↑↓×, cap-caret, phase-drag | `IconButton size="sm"` (32) or `size="xs"` (28) |
| `r-pill`, phase-tag, int-status, fathom-tag, form-card-status, due-pill | `Pill` (`tone`, `dot`; `outline` for neutral on the stone) |
| `r-chip` category / feed chips (Wins, Intros, Coach) | `Tag` |
| a number in a circle (nav "2", "Focus 2") | `CountBadge` |
| the portal's `StatusDot` | `StatusDot` |
| r-bar, phase-progress, phase-rail-progress | `ProgressBar` (`thin` for 4px) / `.cp-progress` |
| UPPERCASE in-card labels ("ON PURCHASE", "CLASSROOMS") | `GroupLabel` (sentence case: "On purchase") |
| cs-row / cs-label | `SettingsRow` in `SettingsList` (`wide` for an input or select that takes the 60% column) |
| cs-savebar | `SaveBar` + `<ToastProvider above=".cp-savebar">` |
| section-switch (a card with an On/Off SegmentedSwitch) | `SettingStrip` (a Toggle) |
| details.call-section, phase-rail-folder-head, cm-replies-toggle | `Disclosure` / `<details class="cp-disclosure">` |
| native radios (programme-grid) | `RadioGroup` (`variant="cards"` for option cards) |
| `<input type="time">` | `TimePicker` (`step`, `min`, `max`, `hour12`) |
| `<input type="color">` + cs-swatch | `ColorField` |
| a hand-made file input / photo field | `FileButton`, `ImageField` (`shape="round"` for a photo, `"wide"` for a cover) |

**The spacing rules** (tokens in `tokens.css`; desktop / phone ≤860px):

- Page gutter `--page-pad` 24 / 16. Sidebar → page 20.
- h1 → subtitle 2. Header → first content `--head-gap` 20 / 16.
- Between cards `--card-gap` 20 / 16 (12 inside a tile grid).
- Card padding `--card-pad` 22 24 / 18 20; tile `--tile-pad` 20 22 / 16 18; a card holding a list
  (rows padded 12) `--list-pad` 6 24 / 6 20 (`cp-card is-list`); a cover card 10.
- An h2 on the stone between groups: 20 above, 12 below (`--section-above` 20 / 16, `--section-below` 12): `cp-section-title`.
- Header actions: right, on the h1's row (not centred on the title block), 38 tall; secondary → primary → ⋯;
  at most two buttons + ⋯; status pills in `meta` beside the h1. Phone: stacked under the subtitle, left.
- Build a page as `<Page>` (or `.cp-page`): PageHeader, then cards; `Stack` / `.cp-stack` for a column
  of cards inside it. Adopting these may move a page by a few px (the inventory counted about 20 of 50
  portal pages, 2–68px): that is the intended fix, but do it as its own commit and look at each page.

## Upgrading v0.5 → v0.6

Nothing was removed or renamed. Visible changes: buttons 42 / 38 tall (were ~38 / ~34; see the `--btn-h` escape above), the
compact select 38 (was 40), the toast's default spot is bottom-centre (`position="bottom-right"` for the old: the portal's was bottom-right), the neutral
pill is a touch darker in light and distinct from the well in dark, skeleton bars are darker so they show on stone.
`DatePreset.range` now also receives `{ min, max }` (old one-argument presets still work).

## The dropdown rule

- **A form field** (pick one) → `Select`.
- **A long list** → `Combobox`.
- **Several values** → the multi-pick, `MultiCombobox`.
- **Actions or filters** → `MenuButton`.
- **Never an action inside a select** ("New subdomain…", "Delete", "+ Add tag"): move it to a `MenuButton`
  or a button next to the field, keeping it in the same place on the page.

## Checks before you commit

- `typecheck` and `lint` pass; the app's own tests pass.
- Light, dark, and 375px wide: nothing scrolls sideways, no text under 12px.
- Keyboard: every swapped control opens, moves, picks and closes with the keys, and focus comes back.
- Radii only 999 / 20 / 14 / 12 / 8; shadows only on pop-ups; `prefers-reduced-motion` respected (the
  package already does this; don't add your own animations around it).
- Diff review: only markup/classes/imports changed. If a handler, a query, or a field's position changed, undo it.
