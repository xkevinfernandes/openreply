/* =============================================================================
   cp-select.js: the custom Select and Combobox for plain HTML pages
   (DataOS, the editor rooms). No build step, no dependencies.

     <link rel="stylesheet" href=".../apps/tokens.css">
     <link rel="stylesheet" href=".../apps/components.css">
     <script src=".../apps/cp-select.js" defer></script>

     <label for="tz">Timezone</label>
     <select id="tz" name="tz" class="cp-select" data-search>…</select>

   Every <select class="cp-select"> (and the v0.3 markup, <span class="cp-select">
   <select>…) is upgraded into the styled list the React <Select> draws:
   a button that looks like an input, a list in a pop-up (top layer, flips
   above, fits the viewport, works inside a <dialog>), a bottom sheet on a
   phone. `data-search` (or class cp-combobox) adds the search box: the
   Combobox, for long lists.

   The native <select> stays in the page, hidden, and holds the value, so a
   form still submits it and `change` / `input` events still fire on it.
   Setting select.value in code redraws the button. Selects added later
   (pages drawn by JS) are upgraded as they appear.

   Per <option>: data-meta (muted, right), data-description (a line under),
   data-keywords (more words the search matches). <optgroup label> gives a
   heading. An empty-value option that is disabled or hidden is the placeholder.

   <select multiple class="cp-select"> is the multi-pick (MultiCombobox in
   React): the picked options show as removable chips in the field, the list
   has a search box and stays open while you pick. Backspace removes the last
   chip; ← steps onto the chips. data-max="3" caps how many. The native
   options' `selected` hold the values (FormData gets them all).

   window.cpSelect.upgrade(selectEl) upgrades one by hand; .refresh(selectEl)
   redraws it after you change its options (or, for a multiple, after you set
   option.selected in code).
   ============================================================================= */
(function () {
  "use strict";
  if (typeof window === "undefined" || window.cpSelect) return;

  var SHEET = "(max-width: 640px)";
  var GAP = 6;
  var EDGE = 8;
  var uid = 0;
  var CHECK = '<svg class="cp-option-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
  var CARET = '<svg class="cp-select-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
  var SEARCH = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4"/></svg>';

  var reduced = function () {
    return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  };
  var canPop = function (el) {
    return typeof el.showPopover === "function";
  };
  function isShown(el) {
    if (canPop(el)) {
      try { return el.matches(":popover-open"); } catch (e) { return false; }
    }
    return el.classList.contains("is-open");
  }
  function showEl(el) {
    if (canPop(el)) { if (!isShown(el)) el.showPopover(); } else el.classList.add("is-open");
  }
  function hideEl(el) {
    if (canPop(el)) { if (isShown(el)) el.hidePopover(); } else el.classList.remove("is-open");
  }

  /* Same as react/popover.ts placePopover. */
  function place(anchor, pop, maxHeight) {
    var r = anchor.getBoundingClientRect();
    var vw = document.documentElement.clientWidth;
    var vh = window.innerHeight;
    var list = pop.querySelector(".cp-pop-scroll");
    var kept = list ? list.scrollTop : 0;
    pop.style.minWidth = Math.round(r.width) + "px";
    pop.style.maxHeight = "none";
    var natural = pop.offsetHeight;
    var below = vh - r.bottom - GAP - EDGE;
    var above = r.top - GAP - EDGE;
    var want = Math.min(natural, maxHeight);
    var up = want > below && above > below;
    pop.style.maxHeight = Math.max(Math.min(want, up ? above : below), 0) + "px";
    var w = pop.offsetWidth;
    var h = pop.offsetHeight;
    var left = Math.max(EDGE, Math.min(r.left, vw - w - EDGE));
    var top = up ? r.top - GAP - h : r.bottom + GAP;
    pop.style.left = Math.round(left) + "px";
    pop.style.top = Math.round(Math.max(EDGE, top)) + "px";
    pop.dataset.side = up ? "top" : "bottom";
    pop.dataset.align = "start";
    if (list) list.scrollTop = kept;
  }

  function rank(o, q) {
    var label = o.label.toLowerCase();
    var hay = (o.label + " " + (o.group || "") + " " + (o.keywords || "")).toLowerCase();
    if (label.indexOf(q) === 0) return 0;
    if (hay.split(/[\s/_,().-]+/).some(function (w) { return w.indexOf(q) === 0; })) return 1;
    if (hay.indexOf(q) >= 0) return 2;
    return -1;
  }

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }

  function upgrade(select) {
    if (!select || select.tagName !== "SELECT" || select.__cpSelect) return;
    if (select.multiple) return upgradeMulti(select);
    var search = select.hasAttribute("data-search") || select.classList.contains("cp-combobox");
    var id = "cps" + ++uid;
    var listId = id + "-list";
    var state = { open: false, active: -1, query: "", rows: [], options: [], placeholder: "Choose…" };
    var buf = "", bufAt = 0, closeTimer = 0;

    /* ---- The markup --------------------------------------------------------- */
    var wrap = select.parentElement && select.parentElement.classList.contains("cp-select")
      ? select.parentElement
      : null;
    if (wrap) {
      var oldChev = wrap.querySelector(".cp-select-chevron");
      if (oldChev) oldChev.remove();
    } else {
      wrap = document.createElement("span");
      wrap.className = "cp-select";
      select.parentNode.insertBefore(wrap, select);
      wrap.appendChild(select);
    }
    wrap.classList.add("is-custom");
    var onWell = select.classList.contains("is-on-well");
    var compact = select.classList.contains("is-compact");
    select.classList.remove("cp-select", "cp-combobox");
    select.classList.add("cp-select-native");
    select.tabIndex = -1;
    select.setAttribute("aria-hidden", "true");

    var label = select.id ? document.querySelector('label[for="' + CSS.escape(select.id) + '"]') : null;
    if (!label) label = select.closest("label");
    if (label && !label.id) label.id = id + "-label";
    var nameText = (label && label.textContent.trim()) || select.getAttribute("aria-label") || "";

    var btn = document.createElement("button");
    btn.type = "button";
    btn.id = id + "-btn";
    btn.className = "cp-input cp-select-trigger" + (onWell ? " is-on-well" : "") + (compact ? " is-compact" : "");
    if (!search) btn.setAttribute("role", "combobox");
    btn.setAttribute("aria-haspopup", "listbox");
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("aria-controls", listId);
    if (label) btn.setAttribute("aria-labelledby", label.id + (search ? " " + id + "-value" : ""));
    else if (nameText) btn.setAttribute("aria-label", nameText);
    if (select.required) btn.setAttribute("aria-required", "true");
    btn.innerHTML = '<span class="cp-select-value" id="' + id + '-value"></span>' + CARET;
    var valueEl = btn.firstChild;
    wrap.insertBefore(btn, select.nextSibling);

    var pop = document.createElement("div");
    pop.className = "cp-pop cp-select-pop";
    pop.setAttribute("popover", "manual");
    pop.innerHTML =
      '<div class="cp-pop-head" aria-hidden="true">' + esc(nameText) + "</div>" +
      (search
        ? '<div class="cp-pop-search">' + SEARCH +
          '<input class="cp-input" type="search" role="combobox" autocomplete="off" spellcheck="false" aria-autocomplete="list" aria-expanded="false" aria-controls="' + listId + '" placeholder="' + esc(select.getAttribute("data-search-placeholder") || "Search") + '" aria-label="Search ' + esc(nameText.toLowerCase()) + '"></div>'
        : "") +
      '<ul class="cp-listbox cp-pop-scroll" role="listbox" id="' + listId + '" tabindex="-1"></ul>';
    var input = pop.querySelector("input");
    var list = pop.querySelector("ul");
    if (label) list.setAttribute("aria-labelledby", label.id);
    else if (nameText) list.setAttribute("aria-label", nameText);
    wrap.insertBefore(pop, btn.nextSibling);

    /* ---- Reading the native select ------------------------------------------ */
    function read() {
      state.options = [];
      state.placeholder = select.getAttribute("data-placeholder") || "Choose…";
      Array.prototype.forEach.call(select.options, function (o, i) {
        if (o.value === "" && (o.disabled || o.hidden)) {
          state.placeholder = o.textContent.trim() || state.placeholder;
          return;
        }
        var g = o.parentElement && o.parentElement.tagName === "OPTGROUP" ? o.parentElement.label : "";
        state.options.push({
          i: i,
          value: o.value,
          label: o.textContent.trim(),
          disabled: o.disabled || (o.parentElement.tagName === "OPTGROUP" && o.parentElement.disabled),
          group: g,
          meta: o.getAttribute("data-meta"),
          description: o.getAttribute("data-description"),
          keywords: o.getAttribute("data-keywords") || ""
        });
      });
      btn.disabled = select.disabled;
    }

    function selectedOpt() {
      var v = select.selectedIndex >= 0 ? select.options[select.selectedIndex] : null;
      if (!v) return null;
      for (var k = 0; k < state.options.length; k++) if (state.options[k].i === select.selectedIndex) return state.options[k];
      return null;
    }

    function renderValue() {
      var o = selectedOpt();
      valueEl.classList.toggle("is-placeholder", !o);
      valueEl.innerHTML = "<span>" + esc(o ? o.label : state.placeholder) + "</span>";
    }

    function filterRows() {
      var q = state.query.trim().toLowerCase();
      if (!search || !q) { state.rows = state.options.slice(); return; }
      state.rows = state.options
        .map(function (o) { return { o: o, r: rank(o, q) }; })
        .filter(function (x) { return x.r >= 0; })
        .sort(function (a, b) { return a.r - b.r || a.o.i - b.o.i; })
        .map(function (x) { return x.o; });
    }

    function renderList() {
      var sel = selectedOpt();
      var grouped = !(search && state.query.trim());
      var html = "";
      var last = null;
      state.rows.forEach(function (o, pos) {
        if (grouped && o.group && o.group !== last) html += '<li role="presentation" class="cp-pop-label">' + esc(o.group) + "</li>";
        last = o.group;
        html +=
          '<li role="option" class="cp-option" id="' + id + "-o" + o.i + '" data-pos="' + pos + '"' +
          ' aria-selected="' + (sel && sel.i === o.i) + '"' + (o.disabled ? ' aria-disabled="true"' : "") + ">" +
          '<span class="cp-option-text"><span class="cp-option-label">' + esc(o.label) + "</span>" +
          (o.description ? '<span class="cp-option-desc">' + esc(o.description) + "</span>" : "") + "</span>" +
          (o.meta ? '<span class="cp-option-meta">' + esc(o.meta) + "</span>" : "") + CHECK + "</li>";
      });
      if (!state.rows.length) html = '<li role="presentation" class="cp-pop-empty">' + esc(select.getAttribute("data-empty") || "No match") + "</li>";
      list.innerHTML = html;
      paintActive();
    }

    function enabledPositions() {
      var out = [];
      state.rows.forEach(function (o, p) { if (!o.disabled) out.push(p); });
      return out;
    }

    function paintActive() {
      var prev = list.querySelector(".cp-option[data-active]");
      if (prev) prev.removeAttribute("data-active");
      var o = state.rows[state.active];
      var el = o ? document.getElementById(id + "-o" + o.i) : null;
      var host = search ? input : btn;
      if (el && state.open) {
        el.setAttribute("data-active", "");
        host.setAttribute("aria-activedescendant", el.id);
        el.scrollIntoView({ block: "nearest" });
      } else host.removeAttribute("aria-activedescendant");
    }

    function setActive(pos) {
      state.active = pos;
      paintActive();
    }

    function move(delta) {
      var en = enabledPositions();
      if (!en.length) return;
      var at = en.indexOf(state.active);
      var next = at < 0 ? (delta > 0 ? 0 : en.length - 1) : Math.max(0, Math.min(en.length - 1, at + delta));
      setActive(en[next]);
    }

    /* ---- Open, close, pick ------------------------------------------------------ */
    function openList(at) {
      if (btn.disabled || state.open) return;
      read();
      state.query = "";
      if (input) input.value = "";
      filterRows();
      var en = enabledPositions();
      var sel = selectedOpt();
      var selPos = sel ? state.rows.indexOf(sel) : -1;
      state.active =
        typeof at === "number" ? at :
        at === "first" ? (en[0] != null ? en[0] : -1) :
        at === "last" ? (en.length ? en[en.length - 1] : -1) :
        selPos >= 0 && !sel.disabled ? selPos : (en[0] != null ? en[0] : -1);
      state.open = true;
      clearTimeout(closeTimer);
      pop.classList.remove("is-closing");
      var sheet = window.matchMedia(SHEET).matches;
      pop.classList.toggle("is-sheet", sheet);
      if (sheet) pop.style.top = pop.style.left = pop.style.minWidth = pop.style.maxHeight = "";
      renderList();
      showEl(pop);
      if (!sheet) place(btn, pop, search ? 400 : 340);
      btn.setAttribute("aria-expanded", "true");
      if (input) {
        input.setAttribute("aria-expanded", "true");
        input.focus({ preventScroll: true });
      }
      paintActive();
      window.addEventListener("resize", onResize);
      window.addEventListener("scroll", onScroll, true);
      document.addEventListener("pointerdown", onDown, true);
    }

    function close(focusBtn) {
      if (!state.open) return;
      state.open = false;
      btn.setAttribute("aria-expanded", "false");
      btn.removeAttribute("aria-activedescendant");
      if (input) input.setAttribute("aria-expanded", "false");
      window.removeEventListener("resize", onResize);
      window.removeEventListener("scroll", onScroll, true);
      document.removeEventListener("pointerdown", onDown, true);
      if (focusBtn !== false) btn.focus({ preventScroll: true });
      if (reduced()) hideEl(pop);
      else {
        pop.classList.add("is-closing");
        closeTimer = setTimeout(function () {
          pop.classList.remove("is-closing");
          hideEl(pop);
        }, pop.classList.contains("is-sheet") ? 200 : 120);
      }
    }

    function pick(pos) {
      var o = state.rows[pos];
      if (!o || o.disabled) return;
      var changed = select.selectedIndex !== o.i;
      nativeIndex.set.call(select, o.i);
      renderValue();
      close(true);
      if (changed) {
        select.dispatchEvent(new Event("input", { bubbles: true }));
        select.dispatchEvent(new Event("change", { bubbles: true }));
      }
    }

    function onResize() {
      if (!pop.classList.contains("is-sheet")) place(btn, pop, search ? 400 : 340);
    }
    function onScroll(e) {
      if (e.target instanceof Node && pop.contains(e.target)) return;
      onResize();
    }
    function onDown(e) {
      var t = e.target;
      if (btn.contains(t)) return;
      if (t !== pop && pop.contains(t)) return;
      if (t === pop) {
        var r = pop.getBoundingClientRect();
        if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) return;
      }
      close(false);
    }

    function jump(ch) {
      var now = Date.now();
      buf = now - bufAt < 600 ? buf + ch.toLowerCase() : ch.toLowerCase();
      bufAt = now;
      var same = buf.split("").every(function (c) { return c === buf[0]; });
      var term = same ? buf[0] : buf;
      var n = state.rows.length;
      var start = same || buf.length === 1 ? state.active + 1 : state.active;
      for (var k = 0; k < n; k++) {
        var i = (((start + k) % n) + n) % n;
        var o = state.rows[i];
        if (!o.disabled && o.label.toLowerCase().indexOf(term) === 0) return i;
      }
      return -1;
    }

    /* ---- Keys -------------------------------------------------------------- */
    function listKey(e) {
      var k = e.key;
      if (k === "ArrowDown") { e.preventDefault(); move(1); }
      else if (k === "ArrowUp") { e.preventDefault(); if (e.altKey) pick(state.active); else move(-1); }
      else if (k === "PageDown") { e.preventDefault(); move(10); }
      else if (k === "PageUp") { e.preventDefault(); move(-10); }
      else if ((k === "Home" || k === "End") && !search) {
        e.preventDefault();
        var en = enabledPositions();
        setActive(k === "Home" ? en[0] : en[en.length - 1]);
      }
      else if (k === "Enter") { e.preventDefault(); if (state.active >= 0) pick(state.active); }
      else if (k === "Escape") { e.preventDefault(); e.stopPropagation(); close(true); }
      else if (k === "Tab") { close(true); }
      else if (k === " " && !search) {
        e.preventDefault();
        if (Date.now() - bufAt < 600 && buf) { var p = jump(" "); if (p >= 0) setActive(p); }
        else if (state.active >= 0) pick(state.active);
      }
      else if (!search && k.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        var q = jump(k);
        if (q >= 0) setActive(q);
      }
    }

    btn.addEventListener("click", function () {
      if (state.open) close(true);
      else openList("selected");
    });
    btn.addEventListener("keydown", function (e) {
      if (btn.disabled) return;
      if (state.open) { if (!search) listKey(e); return; }
      var k = e.key;
      if (k === "ArrowDown" || k === "Enter" || k === " ") { e.preventDefault(); openList("selected"); }
      else if (k === "ArrowUp") { e.preventDefault(); openList(selectedOpt() ? "selected" : "last"); }
      else if (k === "Home" || k === "End") { e.preventDefault(); openList(k === "Home" ? "first" : "last"); }
      else if (k.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        if (search) {
          openList("first");
          input.value = k;
          onQuery();
        } else {
          read();
          filterRows();
          var sel = selectedOpt();
          state.active = sel ? state.rows.indexOf(sel) : -1;
          var p = jump(k);
          openList(p >= 0 ? p : "selected");
        }
      }
    });
    btn.addEventListener("blur", function (e) {
      if (!search && state.open && !pop.contains(e.relatedTarget)) close(false);
    });
    list.addEventListener("mousedown", function (e) { e.preventDefault(); });
    list.addEventListener("pointermove", function (e) {
      var li = e.target.closest && e.target.closest(".cp-option");
      if (!li || li.getAttribute("aria-disabled") === "true") return;
      var pos = Number(li.dataset.pos);
      if (pos !== state.active) setActive(pos);
    });
    list.addEventListener("click", function (e) {
      var li = e.target.closest && e.target.closest(".cp-option");
      if (li) pick(Number(li.dataset.pos));
    });

    function onQuery() {
      state.query = input.value;
      filterRows();
      var en = enabledPositions();
      state.active = en[0] != null ? en[0] : -1;
      renderList();
      if (!pop.classList.contains("is-sheet")) place(btn, pop, 400);
    }
    if (input) {
      input.addEventListener("input", onQuery);
      input.addEventListener("keydown", listKey);
      input.addEventListener("blur", function (e) {
        var to = e.relatedTarget;
        if (state.open && to && !pop.contains(to) && to !== btn) close(false);
      });
    }

    /* ---- Keeping in step with the native select ------------------------------------ */
    var nativeValue = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value");
    var nativeIndex = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "selectedIndex");
    Object.defineProperty(select, "value", {
      configurable: true,
      get: function () { return nativeValue.get.call(this); },
      set: function (v) { nativeValue.set.call(this, v); renderValue(); }
    });
    Object.defineProperty(select, "selectedIndex", {
      configurable: true,
      get: function () { return nativeIndex.get.call(this); },
      set: function (v) { nativeIndex.set.call(this, v); renderValue(); }
    });
    select.addEventListener("change", renderValue);
    select.addEventListener("focus", function () { btn.focus(); });
    var form = select.form;
    if (form) form.addEventListener("reset", function () { setTimeout(renderValue, 0); });
    new MutationObserver(function () {
      read();
      renderValue();
      if (state.open) { filterRows(); renderList(); }
    }).observe(select, { childList: true, subtree: true, attributes: true, attributeFilter: ["disabled", "label", "selected"], characterData: true });

    select.__cpSelect = { refresh: function () { read(); renderValue(); }, open: openList, close: close };
    read();
    renderValue();
  }


  /* ---- The multi-pick ---------------------------------------------------------- */
  var X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  var TICK = '<span class="cp-option-box" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span>';

  function upgradeMulti(select) {
    var id = "cps" + ++uid;
    var listId = id + "-list";
    var state = { open: false, active: -1, query: "", rows: [], options: [], order: [], placeholder: "Choose…" };
    var closeTimer = 0;
    var max = Number(select.getAttribute("data-max")) || 0;

    var wrap = select.parentElement && select.parentElement.classList.contains("cp-select")
      ? select.parentElement
      : null;
    if (!wrap) {
      wrap = document.createElement("span");
      wrap.className = "cp-select";
      select.parentNode.insertBefore(wrap, select);
      wrap.appendChild(select);
    }
    wrap.classList.add("is-custom");
    var onWell = select.classList.contains("is-on-well");
    select.classList.remove("cp-select", "cp-combobox");
    select.classList.add("cp-select-native");
    select.tabIndex = -1;
    select.setAttribute("aria-hidden", "true");

    var label = select.id ? document.querySelector('label[for="' + CSS.escape(select.id) + '"]') : null;
    if (!label) label = select.closest("label");
    if (label && !label.id) label.id = id + "-label";
    var nameText = (label && label.textContent.trim()) || select.getAttribute("aria-label") || "";

    var field = document.createElement("div");
    field.className = "cp-input cp-multi" + (onWell ? " is-on-well" : "");
    field.innerHTML =
      '<ul class="cp-chips" aria-label="' + esc(nameText ? nameText + ", picked" : "Picked") + '"></ul>' +
      '<button type="button" class="cp-multi-trigger" id="' + id + '-btn" aria-haspopup="listbox" aria-expanded="false" aria-controls="' + listId + '">' +
      '<span class="cp-multi-placeholder"></span><span class="cp-vh" id="' + id + '-count"></span></button>' +
      CARET;
    var chips = field.querySelector(".cp-chips");
    var btn = field.querySelector("button");
    var ph = btn.querySelector(".cp-multi-placeholder");
    var count = btn.querySelector(".cp-vh");
    if (label) btn.setAttribute("aria-labelledby", label.id + " " + id + "-count");
    else btn.setAttribute("aria-labelledby", id + "-count");
    if (select.required) btn.setAttribute("aria-required", "true");
    wrap.insertBefore(field, select.nextSibling);

    var live = document.createElement("span");
    live.className = "cp-vh";
    live.setAttribute("aria-live", "polite");
    wrap.insertBefore(live, field.nextSibling);

    var pop = document.createElement("div");
    pop.className = "cp-pop cp-select-pop";
    pop.setAttribute("popover", "manual");
    pop.innerHTML =
      '<div class="cp-pop-head" aria-hidden="true">' + esc(nameText) + "</div>" +
      '<div class="cp-pop-search">' + SEARCH +
      '<input class="cp-input" type="search" role="combobox" autocomplete="off" spellcheck="false" aria-autocomplete="list" aria-expanded="false" aria-controls="' + listId + '" placeholder="' + esc(select.getAttribute("data-search-placeholder") || "Search") + '" aria-label="Search ' + esc(nameText.toLowerCase()) + '"></div>' +
      '<ul class="cp-listbox cp-pop-scroll" role="listbox" aria-multiselectable="true" id="' + listId + '" tabindex="-1"></ul>' +
      '<div class="cp-multi-foot"><span></span><button type="button" class="cp-btn cp-btn-primary cp-btn-sm">Done</button></div>';
    var input = pop.querySelector("input");
    var list = pop.querySelector("ul");
    var footText = pop.querySelector(".cp-multi-foot > span");
    var done = pop.querySelector(".cp-multi-foot > button");
    if (label) list.setAttribute("aria-labelledby", label.id);
    else if (nameText) list.setAttribute("aria-label", nameText);
    wrap.insertBefore(pop, live.nextSibling);

    function read() {
      state.options = [];
      state.placeholder = select.getAttribute("data-placeholder") || "Choose…";
      Array.prototype.forEach.call(select.options, function (o, i) {
        if (o.value === "" && (o.disabled || o.hidden)) {
          state.placeholder = o.textContent.trim() || state.placeholder;
          return;
        }
        var g = o.parentElement && o.parentElement.tagName === "OPTGROUP" ? o.parentElement.label : "";
        state.options.push({
          i: i,
          el: o,
          value: o.value,
          label: o.textContent.trim(),
          disabled: o.disabled || (o.parentElement.tagName === "OPTGROUP" && o.parentElement.disabled),
          group: g,
          meta: o.getAttribute("data-meta"),
          description: o.getAttribute("data-description"),
          keywords: o.getAttribute("data-keywords") || ""
        });
      });
      // Chips keep the order things were picked in; anything picked in code goes last.
      var sel = state.options.filter(function (o) { return o.el.selected; });
      var next = [];
      state.order.forEach(function (old) {
        for (var k = 0; k < sel.length; k++) if (sel[k].el === old.el && next.indexOf(sel[k]) < 0) next.push(sel[k]);
      });
      sel.forEach(function (o) { if (next.indexOf(o) < 0) next.push(o); });
      state.order = next;
      btn.disabled = select.disabled;
      field.classList.toggle("is-disabled", select.disabled);
    }
    function full() { return max > 0 && state.order.length >= max; }
    function off(o) { return o.disabled || (full() && !o.el.selected); }

    function renderField() {
      var html = "";
      state.order.forEach(function (o, k) {
        html += '<li class="cp-chip"><span class="cp-chip-label">' + esc(o.label) + '</span>' +
          '<button type="button" class="cp-chip-x" tabindex="-1" data-k="' + k + '" aria-label="Remove ' + esc(o.label) + '"' + (select.disabled ? " disabled" : "") + ">" + X + "</button></li>";
      });
      chips.innerHTML = html;
      chips.style.display = state.order.length ? "" : "none";
      field.classList.toggle("has-chips", state.order.length > 0);
      ph.textContent = state.order.length ? "" : state.placeholder;
      count.textContent = state.order.length
        ? state.order.length + " picked: " + state.order.map(function (o) { return o.label; }).join(", ")
        : "None picked";
      footText.textContent = (state.order.length ? state.order.length + " picked" : "None picked") + (max ? " · " + max + " at most" : "");
    }

    function filterRows() {
      var q = state.query.trim().toLowerCase();
      if (!q) { state.rows = state.options.slice(); return; }
      state.rows = state.options
        .map(function (o) { return { o: o, r: rank(o, q) }; })
        .filter(function (x) { return x.r >= 0; })
        .sort(function (a, b) { return a.r - b.r || a.o.i - b.o.i; })
        .map(function (x) { return x.o; });
    }

    function renderList() {
      var grouped = !state.query.trim();
      var html = "";
      var last = null;
      state.rows.forEach(function (o, pos) {
        if (grouped && o.group && o.group !== last) html += '<li role="presentation" class="cp-pop-label">' + esc(o.group) + "</li>";
        last = o.group;
        html +=
          '<li role="option" class="cp-option is-multi" id="' + id + "-o" + o.i + '" data-pos="' + pos + '"' +
          ' aria-selected="' + o.el.selected + '"' + (off(o) ? ' aria-disabled="true"' : "") + ">" + TICK +
          '<span class="cp-option-text"><span class="cp-option-label">' + esc(o.label) + "</span>" +
          (o.description ? '<span class="cp-option-desc">' + esc(o.description) + "</span>" : "") + "</span>" +
          (o.meta ? '<span class="cp-option-meta">' + esc(o.meta) + "</span>" : "") + "</li>";
      });
      if (!state.rows.length) html = '<li role="presentation" class="cp-pop-empty">' + esc(select.getAttribute("data-empty") || "No match") + "</li>";
      list.innerHTML = html;
      paintActive();
    }

    function enabledPositions() {
      var out = [];
      state.rows.forEach(function (o, p) { if (!off(o)) out.push(p); });
      return out;
    }
    function paintActive() {
      var prev = list.querySelector(".cp-option[data-active]");
      if (prev) prev.removeAttribute("data-active");
      var o = state.rows[state.active];
      var el = o ? document.getElementById(id + "-o" + o.i) : null;
      if (el && state.open) {
        el.setAttribute("data-active", "");
        input.setAttribute("aria-activedescendant", el.id);
        el.scrollIntoView({ block: "nearest" });
      } else input.removeAttribute("aria-activedescendant");
    }
    function setActive(pos) { state.active = pos; paintActive(); }
    function move(delta) {
      var en = enabledPositions();
      if (!en.length) return;
      var at = en.indexOf(state.active);
      var next = at < 0 ? (delta > 0 ? 0 : en.length - 1) : Math.max(0, Math.min(en.length - 1, at + delta));
      setActive(en[next]);
    }

    function fire() {
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
    }
    function say(t) { live.textContent = t; }

    function toggle(pos) {
      var o = state.rows[pos];
      if (!o || off(o)) return;
      o.el.selected = !o.el.selected;
      if (o.el.selected) state.order.push(o);
      else state.order = state.order.filter(function (x) { return x !== o; });
      say(o.label + (o.el.selected ? " added" : " removed"));
      afterChange();
    }
    function removeAt(k) {
      var o = state.order[k];
      if (!o || select.disabled) return;
      o.el.selected = false;
      state.order.splice(k, 1);
      say(o.label + " removed");
      afterChange();
    }
    function afterChange() {
      var keep = state.active;
      renderField();
      if (state.open) {
        renderList();
        setActive(keep);
        if (!pop.classList.contains("is-sheet")) place(field, pop, 400);
      }
      fire();
    }
    function focusChip(k) {
      var b = chips.querySelectorAll(".cp-chip-x")[k];
      if (b) b.focus({ preventScroll: true });
    }

    function openList(seed) {
      if (btn.disabled || state.open) return;
      read();
      state.query = seed || "";
      input.value = state.query;
      filterRows();
      var en = enabledPositions();
      state.active = en[0] != null ? en[0] : -1;
      state.open = true;
      clearTimeout(closeTimer);
      pop.classList.remove("is-closing");
      field.classList.add("is-open");
      var sheet = window.matchMedia(SHEET).matches;
      pop.classList.toggle("is-sheet", sheet);
      if (sheet) pop.style.top = pop.style.left = pop.style.minWidth = pop.style.maxHeight = "";
      renderList();
      showEl(pop);
      if (!sheet) place(field, pop, 400);
      btn.setAttribute("aria-expanded", "true");
      input.setAttribute("aria-expanded", "true");
      input.focus({ preventScroll: true });
      paintActive();
      window.addEventListener("resize", onResize);
      window.addEventListener("scroll", onScroll, true);
      document.addEventListener("pointerdown", onDown, true);
    }
    function close(focusBtn) {
      if (!state.open) return;
      state.open = false;
      field.classList.remove("is-open");
      btn.setAttribute("aria-expanded", "false");
      input.setAttribute("aria-expanded", "false");
      input.removeAttribute("aria-activedescendant");
      window.removeEventListener("resize", onResize);
      window.removeEventListener("scroll", onScroll, true);
      document.removeEventListener("pointerdown", onDown, true);
      if (focusBtn !== false) btn.focus({ preventScroll: true });
      if (reduced()) hideEl(pop);
      else {
        pop.classList.add("is-closing");
        closeTimer = setTimeout(function () {
          pop.classList.remove("is-closing");
          hideEl(pop);
        }, pop.classList.contains("is-sheet") ? 200 : 120);
      }
    }
    function onResize() { if (!pop.classList.contains("is-sheet")) place(field, pop, 400); }
    function onScroll(e) {
      if (e.target instanceof Node && pop.contains(e.target)) return;
      onResize();
    }
    function onDown(e) {
      var t = e.target;
      if (field.contains(t)) return;
      if (t !== pop && pop.contains(t)) return;
      if (t === pop) {
        var r = pop.getBoundingClientRect();
        if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) return;
      }
      close(false);
    }

    /* Keys and presses */
    field.addEventListener("mousedown", function (e) {
      var t = e.target;
      if (btn.disabled) return;
      var x = t.closest && t.closest(".cp-chip-x");
      if (x) { e.preventDefault(); return; }
      if (t !== btn && !btn.contains(t)) {
        e.preventDefault();
        btn.focus({ preventScroll: true });
        if (state.open) close(true); else openList();
      }
    });
    chips.addEventListener("click", function (e) {
      var x = e.target.closest && e.target.closest(".cp-chip-x");
      if (!x) return;
      removeAt(Number(x.dataset.k));
      if (!state.open) btn.focus({ preventScroll: true });
    });
    chips.addEventListener("keydown", function (e) {
      var x = e.target.closest && e.target.closest(".cp-chip-x");
      if (!x) return;
      var k = Number(x.dataset.k);
      var key = e.key;
      if (key === "ArrowLeft") { e.preventDefault(); focusChip(Math.max(0, k - 1)); }
      else if (key === "ArrowRight") { e.preventDefault(); if (k + 1 < state.order.length) focusChip(k + 1); else btn.focus({ preventScroll: true }); }
      else if (key === "Backspace" || key === "Delete" || key === "Enter" || key === " ") {
        e.preventDefault();
        removeAt(k);
        var to = Math.min(k, state.order.length - 1);
        if (to >= 0) focusChip(to); else btn.focus({ preventScroll: true });
      }
      else if (key === "Escape" || key === "ArrowDown") { e.preventDefault(); btn.focus({ preventScroll: true }); }
    });
    btn.addEventListener("click", function () {
      if (state.open) close(true); else openList();
    });
    btn.addEventListener("keydown", function (e) {
      if (btn.disabled) return;
      var k = e.key;
      if (k === "ArrowDown" || k === "Enter" || k === " ") { e.preventDefault(); openList(); }
      else if (k === "Backspace" || k === "Delete") {
        if (state.order.length) { e.preventDefault(); removeAt(state.order.length - 1); }
      }
      else if (k === "ArrowLeft") {
        if (state.order.length) { e.preventDefault(); focusChip(state.order.length - 1); }
      }
      else if (k.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) { e.preventDefault(); openList(k); }
    });
    list.addEventListener("mousedown", function (e) { e.preventDefault(); });
    list.addEventListener("pointermove", function (e) {
      var li = e.target.closest && e.target.closest(".cp-option");
      if (!li || li.getAttribute("aria-disabled") === "true") return;
      var pos = Number(li.dataset.pos);
      if (pos !== state.active) setActive(pos);
    });
    list.addEventListener("click", function (e) {
      var li = e.target.closest && e.target.closest(".cp-option");
      if (li) toggle(Number(li.dataset.pos));
    });
    done.addEventListener("click", function () { close(true); });
    input.addEventListener("input", function () {
      state.query = input.value;
      filterRows();
      var en = enabledPositions();
      state.active = en[0] != null ? en[0] : -1;
      renderList();
      if (!pop.classList.contains("is-sheet")) place(field, pop, 400);
    });
    input.addEventListener("keydown", function (e) {
      var k = e.key;
      if (k === "ArrowDown") { e.preventDefault(); move(1); }
      else if (k === "ArrowUp") { e.preventDefault(); move(-1); }
      else if (k === "PageDown") { e.preventDefault(); move(10); }
      else if (k === "PageUp") { e.preventDefault(); move(-10); }
      else if (k === "Enter") { e.preventDefault(); if (state.active >= 0) toggle(state.active); }
      else if (k === "Escape") { e.preventDefault(); e.stopPropagation(); close(true); }
      else if (k === "Tab") { close(true); }
      else if (k === "Backspace" && !input.value && state.order.length) { e.preventDefault(); removeAt(state.order.length - 1); }
    });
    input.addEventListener("blur", function (e) {
      var to = e.relatedTarget;
      if (state.open && to && !pop.contains(to) && !field.contains(to)) close(false);
    });

    /* Keeping in step with the native select */
    function refresh() {
      read();
      renderField();
      if (state.open) { filterRows(); renderList(); }
    }
    select.addEventListener("change", function (e) { if (e.isTrusted) refresh(); });
    select.addEventListener("focus", function () { btn.focus(); });
    var form = select.form;
    if (form) form.addEventListener("reset", function () { setTimeout(function () { state.order = []; refresh(); }, 0); });
    new MutationObserver(refresh).observe(select, { childList: true, subtree: true, attributes: true, attributeFilter: ["disabled", "label", "selected"], characterData: true });

    select.__cpSelect = { refresh: refresh, open: openList, close: close };
    read();
    renderField();
  }

  var SELECTOR = "select.cp-select, select.cp-combobox, .cp-select > select";
  function upgradeAll(root) {
    (root || document).querySelectorAll(SELECTOR).forEach(upgrade);
  }

  window.cpSelect = {
    upgrade: upgrade,
    upgradeAll: upgradeAll,
    refresh: function (s) { if (s && s.__cpSelect) s.__cpSelect.refresh(); }
  };

  function start() {
    upgradeAll(document);
    new MutationObserver(function (records) {
      for (var r = 0; r < records.length; r++) {
        var added = records[r].addedNodes;
        for (var n = 0; n < added.length; n++) {
          var node = added[n];
          if (node.nodeType !== 1) continue;
          if (node.matches(SELECTOR)) upgrade(node);
          else if (node.querySelector) upgradeAll(node);
        }
      }
    }).observe(document.documentElement, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
