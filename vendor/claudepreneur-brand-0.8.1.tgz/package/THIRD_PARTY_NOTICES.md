# Third-party notices

The shared app components (`apps/components.css`, `react/`) are Claudepreneur's own.
A few pieces were adapted from **Astryx** (https://github.com/meta/astryx), used under
the MIT licence below. Nothing here depends on Astryx or StyleX at runtime: the
StyleX styles were rewritten as plain CSS on the app brand's tokens.

| our file | adapted from (Astryx `packages/core/src/…`) | what |
|---|---|---|
| `apps/components.css` (`.cp-skel`, `@keyframes cp-skel-fade`) and `react/Skeleton.tsx` | `Skeleton/Skeleton.tsx` | the stepped opacity pulse (25% → 92.5% in ten holds), 1s delay, 100ms stagger per index, alternate loop, off under reduced motion |
| `react/SegmentedSwitch.tsx`, `apps/components.css` (`.cp-seg`) | `SegmentedControl/SegmentedControl.tsx`, `SegmentedControlItem.tsx` | radiogroup with one tab stop, arrow keys move and select (wrapping), Home/End; item sizing and transition timing |
| `react/EmptyState.tsx`, `apps/components.css` (`.cp-empty`) | `EmptyState/EmptyState.tsx` | layout: title over a 360px-wide description, actions 4px further down |
| `apps/components.css` (`.cp-card`, `.cp-list`, `.cp-field`, `.cp-input`, `.cp-select`) | `Card/Card.tsx`, `Field/`, `TextInput/`, `Selector/` | spacing and sizing as rendered with the app theme (card parts 12px apart, list rows 12px with hairlines, label 4px above a 42px control, 16px chevron) |
| `apps/components.css` (`.cp-pop`, `.cp-listbox`, `.cp-option`, `.cp-pop-search`, `.cp-menu-item`), `react/Select.tsx`, `apps/cp-select.js` | `Selector/Selector.tsx`, `Selector/SelectorOption.tsx`, `DropdownMenu/DropdownMenuItem.tsx`, `Popover/Popover.tsx` | the Select popover's look (padded surface, rounded inset rows, selected row 500 with a trailing check, search box at the top of the list, 300–400px list cap, chevron turning over), the select-only combobox keyboard model, flipping to the side with more room |
| `react/Menu.tsx`, `apps/cp-menu.js` | `DropdownMenu/DropdownMenu.tsx`, `DropdownMenuItem.tsx` | menu rows (destructive items recolour only the text), roving focus with wrapping and type-ahead |

The sidebar (`react/Sidebar.tsx`, `.cp-side-*`) is lifted from the client portal's own `components/reel-sidebar.tsx`
(Claudepreneur's), not from Astryx.

## Astryx licence

```
MIT License

Copyright (c) Meta Platforms, Inc. and affiliates.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Simple Icons (service logos, v0.8)

The Connections logos (`react/logos.ts`, and the `LOGOS` block in `apps/cp-connections.js`) are the
SVG path data of **Simple Icons** v16.37.0 (https://simpleicons.org, https://github.com/simple-icons/simple-icons),
released under **CC0 1.0 Universal** (public domain dedication; no attribution required, given here anyway).
They are regenerated with `node scripts/build-logos.mjs <simple-icons/icons>`; only the path is kept and it
is drawn in `currentColor`, never in the brand's own colour.

The marks themselves are trademarks of their owners (Stripe, Kit, Meta, Instagram, Facebook, Notion,
Airtable, Google, Gmail, Google Calendar, Google Sheets, Gemini, Calendly, Anthropic, Supabase,
Vercel, GitHub, Resend, Upstash, Cloudflare, Convex, Linear, TikTok, YouTube, Zoom). CC0 covers the
drawings, not the trademarks: use a logo only to name the service it stands for, as Connections does,
and follow Simple Icons' disclaimer (https://github.com/simple-icons/simple-icons/blob/develop/DISCLAIMER.md).

Not in the set, so they fall back to the initial tile (pass your own `logo` node if you have the
owner's permission): Slack (removed from Simple Icons at Slack's request), Zernio, Tally, GoHighLevel,
OpenAI, Groq, Cal.com (its mark is a wordmark, unreadable in a 40px tile), and Fathom Video (Simple Icons' "Fathom" is Fathom Analytics, a different company).
