# Claudepreneur — Visual Identity (v3): THE WEBSITE BRAND

_Lives in `branding/website/` since 2026-10-30 (moved from `Kaito/00-shared/clients/claudepreneur/visual-identity.md`, which is now a pointer here)._

> **This is the Claudepreneur brand: the look of claudepreneur.com as Kevin approved it on
> 2026-10-29 ("this is my branding").** One brand for everything public: the website, offer pages,
> reels, carousels and Canva. **Not for the internal platforms** (the client portal, DataOS/ContentOS,
> dashboards): those keep their own working look in `branding/apps/`, deliberately separate.
> Read this first; it says what the brand is and how each medium applies it.
>
> **Where the numbers live:** web tokens in `tokens.css` (beside this file); video/reel tokens in
> `Production/engines/hyperframes/studio/assets/brand.css`. Each is an implementation of this
> page. If one disagrees with the
> **values in §2**, that file is the bug.
>
> **The reference build** is the live homepage: `Sales_Pages/components/site-next/` (route
> `/site-next`, served at claudepreneur.com `/`). When in doubt, look at it.

---

## 1. The brand in one paragraph

A person explaining on a whiteboard. A calm white page (Swiss type, lots of air) set on **Kevin's
Canva canvas** (white, grey dots), with **his hand** on it: Biro handwriting and marker marks
(rings, underlines, strikes, ticks, arrows) that land a beat after the words they mark. Colour is
never decoration: each colour **means** something. Proof is **real**: his face, real screenshots,
real clients. It moves like his reels: words arrive, then the marker marks them; scenes travel like
a camera on a board.

---

## 2. Palette — every colour has one job

### Ground and ink

| Token | Hex | Job |
|---|---|---|
| `--white` | `#ffffff` | The page and the canvas |
| `--paper` | `#faf8f6` | Alternate section ground; card fill on white |
| `--paper-2` | `#f3f0eb` | Wells inside paper cards |
| `--dot` | `#e2e2e2` | The canvas dots: **3px dots on a 40px pitch** |
| `--ink` | `#0a0a0a` | Text, the primary button, structure lines |
| `--ink-2` | `#2e2d2a` | Long-form body on paper |
| `--muted` | `#6f6e69` | Secondary text (5.1:1 on white) |
| `--grey` | `#8a887f` | The word that lost; display-size second lines only (3.5:1) |
| `--line` | `#ebe8e2` | Hairlines, input borders |

### Meaning — the marker colours (hand marks, never chrome)

| Token | Hex | Means | Used as |
|---|---|---|---|
| `--yellow` | `#ffdf56` | **The highlighter.** "Read this." | A 50% band behind words: `rgba(255,223,86,.5)`. **At most 3 per page/piece.** Never a button, never a panel, **never on black** |
| `--blue` | `#1800ad` | **"This is the thing."** | Rings, underlines, arrows, the ring on the answer. Marker ink only: never links, buttons or UI chrome |
| `--red` | `#c1291d` | **The problem.** | Strikes, the ring on the problem, the ✕. 5.8:1 on white |
| `--green` | `#2a7a50` | **Good / the aside / the verdict.** | Ticks, Biro asides ("Luke's year, so far"). 5.3:1 on white, 4.6:1 on cream |

`#5fa07e` (the old v2 green) survives only as a **fill tint** (the Lead Engine dot), never as text or
a mark: it is 3.1:1 on white.

### The four engines (tags only)

| Engine | Fill (dot/tag) | Text tone |
|---|---|---|
| Content (Capture) | `#ffdf56` (ring line `#e8c200`, since the fill is too pale as a line) | `#7a6400` |
| Lead (Cultivate trust) | `#5fa07e` | `#2f6b4c` |
| Sales (Close) | `#1800ad` | `#1800ad` |
| Delivery (Compound) | `#d04f58` | `#a8323b` |

Engine colours **only ever tag an engine**. Source: `Sales_Pages/config/site.ts` `ENGINE_COLOR`.

### The six depths (the /depth page only)

Noise `#4a4f57` (name `#2b2e33`) · Spark `#e0b13e` (`#9a6d12`) · Fire `#e2603f` (`#bd3f26`) ·
Flow `#4b8fe0` (`#2463b5`) · Instinct `#9a7ce6` (`#6a4bc0`) · Stillness `#e9eef4` (`#5f6f80`).
Drop/glow colour first, text colour in brackets. Source: `Sales_Pages/config/site-next/depth.ts`.

### Retired

| Was | Why |
|---|---|
| The v2 "noir" look: black `#000→#131313` gradients as the default ground, Archivo Black display, yellow = "the problem" | Replaced by v3 (2026-10-29). Black survives as a **photo card** (`#141414`) and in the stacked logo, not as the page |
| `#d04f58` / `#bf281c` as reds, `#2f8a4f` / `#2F8A5B` as greens | Collapsed into one red `#c1291d` and one green `#2a7a50` |
| Orange `#D97757`, forest `#2D5A3D`/`#367347`, sage `#93C4A4`, cream `#F2F1EC` | Long gone |

---

## 3. Type

| Role | Face | Setting |
|---|---|---|
| Display (h1/h2) | **Inter**, optical size on (`opsz` 32), **500** | Tight: −0.045em; h1 `clamp(2.75rem, 7.2vw, 6rem)`, h2 `clamp(2.25rem, 4.8vw, 4.25rem)`; `text-wrap: balance` |
| Titles (h3, cards) | Inter 500 | −0.03em |
| Body | Inter 400 | 1.0625rem / 1.55, −0.011em; features `cv11`, `ss01` |
| Lead | Inter 400, `--muted` | `clamp(1.125rem, 1.5vw, 1.375rem)`; one phrase may turn `--ink` for emphasis |
| **His hand** | **Biro Script Plus** | Asides, notes, labels on a board. Set ~30% larger than the Inter beside it. **Never body, never a headline, never a button** |

**No eyebrows.** No small label above a heading, ever. The heading speaks alone.
Emphasis comes from the highlighter, a hand mark or weight, never from colour on its own.

### The logo
- **On light grounds (the default now):** the one-line wordmark `/claudepreneur`, Inter, ink, with
  the **slash in `--yellow`** (`Sales_Pages/components/site/Top.tsx` `Wordmark`).
- **On black (photo cards, video end cards):** the stacked logo, "claude" over "preneur", white
  Inter SemiBold, one tall yellow slash leaning 15.1° (artwork:
  `~/Documents/0. Claudepreneur/Logo/1.png`; build: `Sales_Pages/components/Wordmark.tsx`).

### Biro Script Plus
Canonical file: `00-shared/clients/claudepreneur/assets/fonts/BiroScriptPlus.ttf`
(also `Sales_Pages/app/join/fonts/BiroScriptPlus.ttf`, `claudedeck/fonts/`). **Licence:** Fenotype,
via Kevin's licence: his own surfaces only; don't redistribute or commit it to a public repo.

---

## 4. The hand — the mark grammar

His marker is how he points. One mark per idea, on the word it depicts, **a beat after the word lands**.

| Mark | Means | Colour |
|---|---|---|
| Ring | "THIS is the thing" (or, in red, "this is the problem") | blue / red |
| Underline | "this one" | blue (green under a good line) |
| Highlighter band | "read this" | yellow, ≤3 per piece |
| Strike | "not this" | red, always |
| Cross ✕ | "this doesn't happen" | red |
| Tick ✓ | done / yes | green |
| Arrow | from → to, a person pointing | by meaning |
| Biro aside | his own words: a note, a verdict | green (blue for a statement of belief) |

- Marks are drawn strokes (SVG paths that draw on), slightly imperfect, never perfect ellipses.
- A mark never covers a word. A drawing that stops mattering **dims**, it isn't erased.
- **One hand mark per section** on the web; a board in a reel follows `WHITEBOARD.md`.

---

## 5. Grounds, cards and space

- **The canvas:** `#ffffff` with `#e2e2e2` dots (3px, 40px pitch). Use it where a thought is
  *drawn* (the hero, whiteboard scenes, the engine board, the wins board, the close). Masked to fade
  at the edges on the web.
- **Paper cards:** `--paper` fill on white (or white on paper), radius **1.75rem** (28px), no border,
  at most a very soft shadow. Pairs of cards are **matched** (same fill, radius, padding, shared rows).
- **The photo card:** real photography in a rounded dark card `#141414` (radius 28–40px).
- **Space (Apple-grade):** page wrap 1200px, gutter `clamp(16px, 4vw, 40px)`, section padding
  `clamp(88px, 12vw, 152px)`, tight groups and generous separation, more space above a heading than
  below. Everything works at 375px.

---

## 6. Motion

- **One ease:** `cubic-bezier(.22, 1, .36, 1)`. Smooth scroll (Lenis). Words rise out of a short blur;
  marks draw on **after** the words (the hero: "business." lands and is ringed **before** "Not a
  bigger team." arrives).
- **Scroll-driven scenes** pin and scrub: the whiteboard problem, the stack vs the loop, the
  hand-drawn engine that assembles, steps through each engine and **turns once**. The camera moves
  like his reels (whip across, dolly in, pull back; never the same move twice running).
- Motion performs: no idle wobble, no decorative loops. Full `prefers-reduced-motion` fallback.

---

## 7. Proof and imagery

Real things over drawn stand-ins: Kevin's photo, clients' faces (with the blue check), real
screenshots of messages and deal alerts, real numbers. No stock, no clip-art people, no invented
testimonials.

---

## 8. Applying it, medium by medium

| Medium | Implementation | What v3 means there |
|---|---|---|
| **Website** (claudepreneur.com) | `Sales_Pages/components/site-next/`, `app/site/site.css` tokens | The reference build. Done. |
| **Offer pages / funnels** (ai.claudepreneur.com) | `Sales_Pages/lib/dm-setter-theme.tsx`, `noir-theme.tsx`, the default offer template | **To migrate:** white/paper grounds, Inter 500 display, one hand mark per section, the highlighter ≤3 |
| **Reels / video** (hyperframes) | `Production/engines/hyperframes/studio/assets/brand.css` | Already the canvas + markers (`--canva-ground`, `--canva-dot`, `--wb-*`). v3 aligns the marker values (red `#c1291d`, green `#2a7a50`, blue `#1800ad`) and the meaning table above. Footage keeps its own rules (yellow ink on footage) |
| **Carousels** | `Production/factory/carousel-editor/fixtures/brand.json` (measured from the "My Story" Canva carousel) | Two formats: **photo carousel** (dark photo card, white Inter, one yellow block or band, as measured) and **whiteboard carousel** (white canvas + dots, Inter 500 print, Biro asides, marks in the colours above). Same type, same colour meanings. *Not yet wired into the tool* (it's mid-build); use this table |
| **Canva** | Brand Kit (manual, see §9) | Set the kit so every new design starts in v3 |
| **Internal platforms** (portal, DataOS/ContentOS, dashboards) | `branding/apps/` | **Out of scope: a separate brand** (Kevin, 2026-10-29). Don't apply v3 there |
| **Decks** | `Kaito/claudedeck/theme.css` | **To migrate** to v3 |

---

## 9. Canva Brand Kit (enter these)

The Canva connector wasn't available when this was written, so the kit is set by hand
(Canva → Brand → Brand Kit):

- **Colours, in this order, named:** Ink `#0A0A0A` · White `#FFFFFF` · Paper `#FAF8F6` ·
  Dot grey `#E2E2E2` · Highlighter `#FFDF56` · Marker blue `#1800AD` · Marker red `#C1291D` ·
  Marker green `#2A7A50` · Muted `#6F6E69` · Photo card `#141414`
- **Fonts:** Heading **Inter Medium** (tracking −45 to −50) · Subheading Inter Medium · Body
  **Inter Regular** · Handwriting **Biro Script Plus** (upload the .ttf from §3)
- **Logos:** the `/claudepreneur` wordmark (light) and the stacked logo (black)
- **The canvas:** a 1080×1350 and 1080×1920 template with white ground + `#E2E2E2` dots (3px / 40px)
- **Rules to keep in Canva:** yellow only as a translucent band behind words; blue/red/green only as
  hand marks; no small labels above headings; real photos and screenshots.

---

## Changelog

- **2026-10-29 — v3.** Kevin approved claudepreneur.com's rebuilt homepage as the brand ("this is my
  branding … for Canva, hyperframes and my carousels"). This file is rewritten from the shipped
  site. Unifies the three palettes (web v2 noir, video, decks) into one meaning-based palette:
  one red `#c1291d`, one green `#2a7a50`, marker blue `#1800ad`, yellow as the highlighter only.
  Retires the noir ground and Archivo Black. Adds the hand grammar, the canvas, motion and the
  per-medium table. Internal platforms (portal, DataOS) keep their own look in `branding/apps/`. The v2 text is in git history.
- 2026-07-22: v2 created (noir palette from the Canva system, `#5fa07e`, `#ffdf56`, `#faf8f6`,
  `#000→#131313`, Biro Script Plus as a graphics font).
