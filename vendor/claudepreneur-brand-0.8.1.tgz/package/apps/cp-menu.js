/* =============================================================================
   cp-menu.js: the MenuButton for plain HTML pages. No build, no dependencies.

     <button class="cp-btn" data-cp-menu="client-more">More</button>
     <div class="cp-pop" id="client-more">
       <div class="cp-menu" role="menu" aria-label="More">
         <button class="cp-menu-item" role="menuitem">Rename</button>
         <div class="cp-pop-sep" role="separator"></div>
         <button class="cp-menu-item is-danger" role="menuitem">Unlink</button>
       </div>
     </div>

   Enter, Space or ↓ opens on the first item (↑ on the last); the arrow keys
   move (wrapping), Home/End jump, a letter jumps; Enter/Space runs the item
   (your own click handler), Esc or Tab closes and focus goes back to the
   button; a press outside closes it. It floats in the top layer (works in a
   <dialog>), flips above when needed, and is a bottom sheet on a phone.
   A role="menuitemcheckbox" item keeps the menu open. data-align="start"
   on the button lines the menu up with its left edge (default right).
   Buttons added later are wired up as they appear.

   v0.6, a help line under an item (CSS only):
     <button class="cp-menu-item has-desc" role="menuitem">
       <span class="cp-menu-text"><span class="cp-menu-label">Form</span>
       <span class="cp-menu-desc">Ask the client to fill something in</span></span>
     </button>

   v0.6, a submenu: data-cp-submenu on the row names another .cp-pop (put it
   inside the parent pop, after its .cp-menu):
     <button class="cp-menu-item" role="menuitem" data-cp-submenu="add-form">Form</button>
     <div class="cp-pop" id="add-form">
       <div class="cp-menu" role="menu" aria-label="Form">…items…</div>
     </div>
   → or Enter (or a click, or hovering with a mouse) opens it beside the row;
   ← or Esc closes it and focus goes back to the row. On a phone it is a
   second sheet with a Back row.
   ============================================================================= */
(function () {
  "use strict";
  if (typeof window === "undefined" || window.cpMenu) return;
  var SHEET = "(max-width: 640px)";
  var GAP = 6;
  var EDGE = 8;
  var openOne = null;

  function shown(el) {
    try { return el.matches(":popover-open"); } catch (e) { return el.classList.contains("is-open"); }
  }
  function show(el) {
    if (el.showPopover) { if (!shown(el)) el.showPopover(); } else el.classList.add("is-open");
  }
  function hide(el) {
    if (el.hidePopover) { if (shown(el)) el.hidePopover(); } else el.classList.remove("is-open");
  }
  function place(btn, pop, align) {
    var r = btn.getBoundingClientRect();
    var vw = document.documentElement.clientWidth;
    var vh = window.innerHeight;
    pop.style.maxHeight = "none";
    var natural = pop.offsetHeight;
    var below = vh - r.bottom - GAP - EDGE;
    var above = r.top - GAP - EDGE;
    var want = Math.min(natural, 420);
    var up = want > below && above > below;
    pop.style.maxHeight = Math.max(Math.min(want, up ? above : below), 0) + "px";
    var w = pop.offsetWidth;
    var h = pop.offsetHeight;
    var left = align === "start" ? r.left : r.right - w;
    left = Math.max(EDGE, Math.min(left, vw - w - EDGE));
    pop.style.left = Math.round(left) + "px";
    pop.style.top = Math.round(Math.max(EDGE, up ? r.top - GAP - h : r.bottom + GAP)) + "px";
    pop.dataset.side = up ? "top" : "bottom";
    pop.dataset.align = align;
  }
  // A level's own rows (not the rows of a submenu nested inside it).
  var items = function (pop) {
    return Array.prototype.slice.call(
      pop.querySelectorAll('[role^="menuitem"]:not([aria-disabled="true"]):not(:disabled)')
    ).filter(function (el) { return el.closest(".cp-pop") === pop; });
  };
  function placeBeside(row, pop) {
    var r = row.getBoundingClientRect();
    var vw = document.documentElement.clientWidth;
    var vh = window.innerHeight;
    pop.style.maxHeight = Math.min(420, vh - EDGE * 2) + "px";
    var w = pop.offsetWidth, h = pop.offsetHeight;
    var right = r.right + 4, left = r.left - 4 - w;
    var toRight = right + w <= vw - EDGE || left < EDGE;
    var x = toRight ? Math.min(right, vw - w - EDGE) : left;
    pop.style.left = Math.round(Math.max(EDGE, x)) + "px";
    pop.style.top = Math.round(Math.max(EDGE, Math.min(r.top - 6, vh - h - EDGE))) + "px";
    pop.dataset.side = toRight ? "right" : "left";
  }
  var CARET = '<svg class="cp-menu-sub-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
  var BACK = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg><span class="cp-menu-label">Back</span>';

  // Open submenus, outermost first: { row, pop }.
  function subs() { return openOne ? openOne.subs : []; }
  function closeSubsFrom(depth, focusRow) {
    var list = subs();
    while (list.length > depth) {
      var s = list.pop();
      s.row.setAttribute("aria-expanded", "false");
      var back = s.pop.querySelector(".cp-menu-back");
      if (back) back.remove();
      hide(s.pop);
      if (focusRow && list.length === depth) s.row.focus({ preventScroll: true });
    }
  }
  function depthOf(pop) {
    if (openOne && pop === openOne.pop) return 0;
    var list = subs();
    for (var i = 0; i < list.length; i++) if (list[i].pop === pop) return i + 1;
    return -1;
  }
  function openSub(row, focusFirst) {
    if (!openOne) return;
    var sub = document.getElementById(row.getAttribute("data-cp-submenu"));
    if (!sub) return;
    var level = depthOf(row.closest(".cp-pop"));
    var list = subs();
    if (list[level] && list[level].pop === sub) {
      if (focusFirst) { var f = items(sub)[0]; if (f) f.focus({ preventScroll: true }); }
      return;
    }
    closeSubsFrom(level, false);
    var sheet = openOne.pop.classList.contains("is-sheet");
    sub.classList.toggle("is-sheet", sheet);
    if (sheet && !sub.querySelector(".cp-menu-back")) {
      var menu = sub.querySelector('[role="menu"]') || sub;
      var back = document.createElement("button");
      back.type = "button";
      back.className = "cp-menu-item cp-menu-back";
      back.setAttribute("role", "menuitem");
      back.tabIndex = -1;
      back.innerHTML = BACK;
      menu.insertBefore(back, menu.firstChild);
    }
    if (sheet) sub.style.top = sub.style.left = sub.style.maxHeight = "";
    show(sub);
    if (!sheet) placeBeside(row, sub);
    row.setAttribute("aria-expanded", "true");
    list.push({ row: row, pop: sub });
    if (focusFirst) { var first = items(sub)[0]; if (first) first.focus({ preventScroll: true }); }
  }
  function isInside(t) {
    if (!openOne) return false;
    if (t !== openOne.pop && openOne.pop.contains(t)) return true;
    var list = subs();
    for (var i = 0; i < list.length; i++) {
      var p = list[i].pop;
      if (t !== p && p.contains(t)) return true;
      if (t === p && !p.classList.contains("is-sheet")) return true;
    }
    return false;
  }

  function close(focusBtn) {
    if (!openOne) return;
    closeSubsFrom(0, false);
    var o = openOne;
    openOne = null;
    o.btn.setAttribute("aria-expanded", "false");
    document.removeEventListener("pointerdown", onDown, true);
    window.removeEventListener("resize", onMove);
    window.removeEventListener("scroll", onScroll, true);
    if (focusBtn !== false) o.btn.focus({ preventScroll: true });
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return hide(o.pop);
    o.pop.classList.add("is-closing");
    setTimeout(function () {
      o.pop.classList.remove("is-closing");
      if (openOne && openOne.pop === o.pop) return;
      hide(o.pop);
    }, 120);
  }
  function onDown(e) {
    if (!openOne) return;
    var t = e.target;
    if (openOne.btn.contains(t)) return;
    // A tap on a submenu sheet's scrim goes back a level.
    var list = subs();
    for (var i = list.length - 1; i >= 0; i--) {
      if (t === list[i].pop && list[i].pop.classList.contains("is-sheet")) {
        var r0 = t.getBoundingClientRect();
        if (e.clientX < r0.left || e.clientX > r0.right || e.clientY < r0.top || e.clientY > r0.bottom) {
          e.stopPropagation();
          closeSubsFrom(i, true);
        }
        return;
      }
    }
    if (isInside(t)) return;
    if (t === openOne.pop) {
      var r = openOne.pop.getBoundingClientRect();
      if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) return;
    }
    close(false);
  }
  function onMove() {
    if (openOne && !openOne.pop.classList.contains("is-sheet")) place(openOne.btn, openOne.pop, openOne.align);
  }
  function onScroll(e) {
    if (openOne && e.target instanceof Node && openOne.pop.contains(e.target)) return;
    onMove();
  }

  function open(btn, pop, at) {
    if (openOne) close(false);
    var align = btn.getAttribute("data-align") === "start" ? "start" : "end";
    openOne = { btn: btn, pop: pop, align: align, subs: [] };
    pop.classList.remove("is-closing");
    var sheet = window.matchMedia(SHEET).matches;
    pop.classList.toggle("is-sheet", sheet);
    if (sheet) pop.style.top = pop.style.left = pop.style.maxHeight = "";
    show(pop);
    if (!sheet) place(btn, pop, align);
    btn.setAttribute("aria-expanded", "true");
    var list = items(pop);
    var el = at === "last" ? list[list.length - 1] : list[0];
    if (el) el.focus({ preventScroll: true });
    document.addEventListener("pointerdown", onDown, true);
    window.addEventListener("resize", onMove);
    window.addEventListener("scroll", onScroll, true);
  }

  function wire(btn) {
    if (btn.__cpMenu) return;
    var pop = document.getElementById(btn.getAttribute("data-cp-menu"));
    if (!pop) return;
    btn.__cpMenu = true;
    if (!pop.hasAttribute("popover")) pop.setAttribute("popover", "manual");
    pop.classList.add("cp-pop", "cp-menu-pop");
    var menu = pop.querySelector('[role="menu"]') || pop;
    if (!menu.id) menu.id = pop.id + "-menu";
    btn.setAttribute("aria-haspopup", "menu");
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("aria-controls", menu.id);
    btn.addEventListener("click", function () {
      if (openOne && openOne.btn === btn) close(true);
      else open(btn, pop, "first");
    });
    btn.addEventListener("keydown", function (e) {
      if (e.key === "ArrowDown" || e.key === "Enter" || e.key === " ") { e.preventDefault(); open(btn, pop, "first"); }
      else if (e.key === "ArrowUp") { e.preventDefault(); open(btn, pop, "last"); }
    });
    wireLevel(pop);
  }

  // Keys, clicks and hover for one level (the menu or a submenu).
  function wireLevel(pop) {
    if (pop.__cpMenuLevel) return;
    pop.__cpMenuLevel = true;
    var menu = pop.querySelector('[role="menu"]') || pop;
    if (!menu.id && pop.id) menu.id = pop.id + "-menu";
    menu.classList.add("cp-pop-scroll");
    items(pop).forEach(function (it) { it.tabIndex = -1; });
    pop.querySelectorAll("[data-cp-submenu]").forEach(function (row) {
      if (row.closest(".cp-pop") !== pop || row.__cpSub) return;
      var sub = document.getElementById(row.getAttribute("data-cp-submenu"));
      if (!sub) return;
      row.__cpSub = true;
      row.classList.add("has-sub");
      row.setAttribute("aria-haspopup", "menu");
      row.setAttribute("aria-expanded", "false");
      if (!row.querySelector(".cp-menu-sub-caret")) row.insertAdjacentHTML("beforeend", CARET);
      if (!sub.hasAttribute("popover")) sub.setAttribute("popover", "manual");
      sub.classList.add("cp-pop", "cp-menu-pop", "cp-submenu");
      var subMenu = sub.querySelector('[role="menu"]') || sub;
      if (!subMenu.id) subMenu.id = sub.id + "-menu";
      row.setAttribute("aria-controls", subMenu.id);
      wireLevel(sub);
    });
    var buf = "", at = 0;

    pop.addEventListener("keydown", function (e) {
      if (!openOne) return;
      var level = depthOf(pop);
      if (level < 0) return;
      var list = items(pop);
      var i = list.indexOf(document.activeElement);
      var here = document.activeElement && document.activeElement.closest && document.activeElement.closest(".cp-pop");
      if (here !== pop) return; // a deeper level's key
      var go = function (n) { var el = list[(n + list.length) % list.length]; if (el) el.focus(); };
      var done = function () { e.preventDefault(); e.stopPropagation(); };
      if (e.key === "ArrowDown") { done(); go(i + 1); }
      else if (e.key === "ArrowUp") { done(); go(i - 1); }
      else if (e.key === "Home") { done(); go(0); }
      else if (e.key === "End") { done(); go(list.length - 1); }
      else if (e.key === "ArrowRight") {
        var row = list[i];
        if (row && row.hasAttribute("data-cp-submenu")) { done(); openSub(row, true); }
      }
      else if (e.key === "ArrowLeft") { if (level > 0) { done(); closeSubsFrom(level - 1, true); } }
      else if (e.key === "Escape") {
        done();
        if (level > 0) closeSubsFrom(level - 1, true);
        else close(true);
      }
      else if (e.key === "Tab") { done(); close(true); }
      else if (e.key.length === 1 && e.key !== " " && !e.metaKey && !e.ctrlKey && !e.altKey) {
        done();
        var now = Date.now();
        buf = now - at < 600 ? buf + e.key.toLowerCase() : e.key.toLowerCase();
        at = now;
        for (var k = 1; k <= list.length; k++) {
          var el = list[(i + k) % list.length];
          if (el.textContent.trim().toLowerCase().indexOf(buf) === 0) { el.focus(); break; }
        }
      }
    });
    pop.addEventListener("click", function (e) {
      var it = e.target.closest && e.target.closest('[role^="menuitem"]');
      if (!it || it.closest(".cp-pop") !== pop) return;
      e.stopPropagation();
      if (it.getAttribute("aria-disabled") === "true") return;
      if (it.classList.contains("cp-menu-back")) { closeSubsFrom(depthOf(pop) - 1, true); return; }
      if (it.hasAttribute("data-cp-submenu")) {
        var lvl = depthOf(pop);
        var open = subs()[lvl];
        if (open && open.row === it && e.detail !== 0) closeSubsFrom(lvl, false);
        else openSub(it, e.detail === 0);
        return;
      }
      if (it.getAttribute("role") === "menuitemcheckbox") {
        it.setAttribute("aria-checked", it.getAttribute("aria-checked") === "true" ? "false" : "true");
        return;
      }
      close(true);
    });
    pop.addEventListener("pointerover", function (e) {
      if (e.pointerType !== "mouse" || !openOne || pop.classList.contains("is-sheet")) return;
      var it = e.target.closest && e.target.closest('[role^="menuitem"]');
      if (!it || it.closest(".cp-pop") !== pop || it.getAttribute("aria-disabled") === "true") return;
      var level = depthOf(pop);
      if (level < 0) return;
      if (it.hasAttribute("data-cp-submenu")) openSub(it, false);
      else closeSubsFrom(level, false);
    });
  }

  function wireAll(root) {
    (root || document).querySelectorAll("[data-cp-menu]").forEach(wire);
  }
  window.cpMenu = { wire: wire, wireAll: wireAll, close: close, openSub: openSub };
  function start() {
    wireAll(document);
    new MutationObserver(function (records) {
      for (var r = 0; r < records.length; r++) {
        var added = records[r].addedNodes;
        for (var n = 0; n < added.length; n++) {
          var node = added[n];
          if (node.nodeType === 1) {
            if (node.matches("[data-cp-menu]")) wire(node);
            else if (node.querySelector) wireAll(node);
          }
        }
      }
    }).observe(document.documentElement, { childList: true, subtree: true });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
