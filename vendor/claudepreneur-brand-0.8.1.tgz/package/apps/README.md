# Branding: THE APP BRAND (the reel look)

_Lives in `branding/apps/` since 2026-10-30 (was `branding/`). For Kevin's own apps: the client portal, DataOS/ContentOS, DM OS, dashboards, any custom tool. The public brand is `../website/`._

The default for every app, tool and dashboard. Since 2026-10-22 that is the
**reel look**: the reel Kevin chose on 2026-10-21, built into ContentOS and the
client portal the same day. It replaces the earlier white-page, 4px-hairline
look (kept in `_previous-2026-10-21/` for reference only; don't build on it).

`tokens.css` holds the numbers. This file holds the rules. The original spec
and the boards it came from live in
`DataOS/.claude/handoffs/contentos-reel-look/` (DESIGN.md, v2-spec.md, boards/).

**Video and social are not in here.** Reels, carousels and cards keep their own
brand in `Production/engines/hyperframes/studio/assets/brand.css`. They share
Inter and the meaning of green, red and yellow.

## The feel

Warm stone ground with white cards floating on it: big soft corners, **no
borders, no shadows**. Big black numbers. One ink feature tile per row. Real
pictures first (covers, avatars). If a block looks like a classic admin table
in a box, it's wrong.

## Type

- **Inter everywhere**, features `cv11` and `ss01` on. Nothing else, not even for display.
  Set the way claudepreneur.com sets it: optical sizing on (display `opsz` 32 for the big type), lighter
  weights, tracking tightened with size; body tracking −0.011em.
- h1 24/500, tracking −0.035em; subtitle 14 muted, 2px below.
- Section title (h2 in a card) 17/500, −0.025em. Pop-up and empty-state titles 17/600.
- Stat: label 12 muted **above** the number; number 28/400 −0.045em tabular-nums; foot 12 (▲ good / ▼ bad colour).
- Body 14, secondary 13, meta 12. **12px is the floor** for any text in the UI (labels, group labels, badges); 11px only for a badge printed on an image.
- Hierarchy comes from size and weight, not colour.

## Colour

Colour means something, or it isn't used.

| token | light | dark | meaning |
|---|---|---|---|
| bg | `#E6E5DE` | `#161615` | the page (stone) |
| card | `#FFFFFF` | `#232322` | cards, sidebar, dialogs |
| well | `#F5F4F0` | `#2D2D2B` | inside a card: tracks, sub-stats, picked row, hover |
| ink | `#111111` | `#ECECEA` | text, primary button, picked pill |
| muted | `#5A5953` | `#A3A29C` | labels, meta |
| line | `#E4E3DD` | `#353532` | table and list row dividers |
| line-input | `#C9C8C0` | `#45453F` | the 1px border round inputs and selects |
| good | `#2F8A5B` | `#5CC98A` | up, beat the usual (≥2× = winner) |
| bad | `#C1291D` | `#F2786B` | down, failed |
| feature | `#0A0A0A` | `#F2F1EC` | the one feature (picked) stat tile per row: ink, with on-ink text and `feature-text` (`#B9B7AF` / `#5C5B56`) for its label and foot |
| like | `#FFDF56` | `#FFDF56` | the one saved/starred thing |

- **Green** good, **red** bad, **amber** "decide this" (warning), **ink** the
  one feature or picked stat per row (black in light, near-white in dark; there
  is no sage any more), **yellow** the one saved/starred thing,
  at most once per view, always with ink text, never a button or panel.
- Status as pills: good / neutral / bad (and warn) pill pairs in tokens.css.
- No gradients, no blue, no brand colour on chrome.

## Shape and space (exact)

- Page padding 24px; gap between cards 20px; inside a card 14–16px.
- **Spacing tokens (v0.7)**, measured off the portal (most pages already use them). Desktop / phone (≤860px):

  | token | desktop | phone | what |
  |---|---|---|---|
  | `--page-pad` | 24 | 16 | the shell's gutter |
  | `--head-gap` | 20 | 16 | page header → first content |
  | `--card-gap` | 20 | 16 | between cards (12 inside a tile grid) |
  | `--card-pad` | 22 24 | 18 20 | a card |
  | `--tile-pad` | 20 22 | 16 18 | a stat / compact tile, a SettingStrip |
  | `--list-pad` | 6 24 | 6 20 | a card holding a list (rows padded 12): `cp-card is-list` |
  | `--section-above` / `--section-below` | 20 / 12 | 16 / 12 | an h2 on the stone between groups of cards |

  Helpers: `cp-page` (a column: header, then cards `--card-gap` apart, `--head-gap` under the header),
  `cp-stack` (cards in a column; `is-tight` = 12), `cp-section-title` (the h2 on the stone, inside a
  cp-page / cp-stack). React: `Page`, `Stack`, `SectionTitle`. h1 → subtitle stays 2.
- Card: card background, radius 20, padding 22px 24px (compact tile 20px 22px). No border, no shadow.
- Inner well: well background, radius 12, padding 10px 12px.
- Covers: radius 14, `object-fit: cover`, 9:16. Table thumbs 44×78 radius 8.
- Pills, switches, badges, avatars: radius 999.
- **Allowed radii: 999, 20, 14, 12, 8. Nothing else.**
- Pop-ups and menus are the one place a soft shadow is allowed (they float over content).

## Building blocks — use the shared components, don't invent variants

These are built once in `components.css` (`cp-` classes) and `@claudepreneur/brand/react`
(see the package README). Use them instead of restyling your own. The numbers:

- **Page header**: row, space-between, wraps; left h1 + subtitle, right controls. v0.7 slots: `back`
  (a `cp-back` link, 13/500 muted with a chevron, above the h1), `meta` (status pills / a count beside the
  h1: a status pill never sits in the action row; a neutral pill there is an outline), and the actions on
  the h1's row, 38 tall, in the order secondary → primary → ⋯ (at most two buttons + ⋯); on a phone they
  stack on the left under the subtitle.
- **Segmented switch**: a radiogroup. Pill track (card colour on stone, well colour inside a card), padding 4, gap 4; options 13/500, padding 8px 14px; **picked = ink pill with on-ink text**, others transparent in ink at 78%. Arrow keys move and pick.
- **Stat tiles**: `repeat(auto-fit, minmax(170px, 1fr))`, gap 20 (two across, gap 12, on a phone). Exactly one **ink feature tile** per row (the picked/sorted one). No outlines.
- **Card**: parts 12px apart (head, then content). A list in a card: rows padded 12px with a 1px line between, none above the first or below the last; row title 14/600, meta 12 muted.
- **Cover card**: white card padding 10, radius 20; cover radius 14 with a badge top-left; hook 14/600 two-line clamp, meta 12 muted.
- **Table**: inside a card; header 12/500 muted with no band; rows 14 with a 1px line on top, ≥60px tall with a thumb; numbers right-aligned tabular; the multiple as a pill.
- **List row** (split views): padding 12, radius 14; picked row = well background.
- **Buttons**: primary ink / on-ink, radius 12, padding 11px 18px, 13/600, no border. Secondary the same on well. Text button: no background, 13/500.
- **Inputs**: label 12 muted, 4px above (or inline: label left 14 ink, control right, for a settings row); card background on stone (well inside a card or pop-up), 1px `line-input` border, radius 12, padding 10px 14px (42px tall).
- **Control heights** (tokens `--control-h` 42, `--control-h-sm` 38): input, select, date field and button share them so a row lines up; compact select, small button and small input are 38. An app's own inputs/buttons use the tokens.
- **Dropdowns** (one rule for every app): a form field → **Select** (custom: never the operating system's menu); a long list → **Combobox** (the Select with a search box); several values → the **multi-pick** (MultiCombobox); actions or filters → **MenuButton**, never an action inside a select. The trigger looks like an input with a 16px muted chevron that turns over while open.
- **Multi-pick**: the input's look with the picked values inside as chips (pills on the other surface colour, 13/500, a round 20px × that is muted until hovered), wrapping onto more lines; the list is the Combobox's, each row with an 18px round tick on the left (a ring, ink with an on-ink check when picked), and it stays open while you pick. Phone: the sheet with "N picked" and a Done button at the foot.
- **Pop-up list / menu**: a floating card (card colour, radius 20, padding 6, the pop shadow; a faint rim in dark), rows 36px, radius 14, 14px text; the row under the keyboard or pointer is a well; the picked option is 500 with a check on the right; group headings 12/500 muted; dividers 1px line. It flips above the trigger when there is more room and never runs off screen. Phone: a bottom sheet with the field's name on top, 44px rows.
- **Date range**: presets left, calendar right (two months on a wide screen); the range is a well band with ink ends; today bold; Apply. Or the presets inline as a switch (7d / 30d / 90d / All) with a Custom pill that opens the calendar.
- **Date picker** (one date): the input's look with a calendar icon; the same calendar, one month; a press picks and closes; Today / Clear in the foot.
- **Menu rows** can carry a 12 muted help line under the label, and open a submenu beside them (a chevron on the right).
- **Toggle**: 36×22 pill, bar grey off, ink on, knob slides on the spring. **Icon button**: 36px round, muted icon, well on hover.
- **Toast**: the portal's ink chip, radius 12, bottom centre by default (`position="bottom-right"` for the portal's old spot; full width on a phone), a tone dot, at most three, leaves on its own; it sits above a sticky save bar, never over it.
- **Confirm**: the pop-up at 420px; a danger confirm is the one red button, and Cancel has the focus. Never `window.confirm`.
- **Loading button**: keeps its label and width, dims and breathes. No spinners anywhere.
- **Pop-up**: native `<dialog>` with `showModal()`, width 520, radius 20, padding 22px 24px, title 17/600 with a round × top right, actions bottom right. Esc, backdrop or × closes; focus stays inside and goes back to the opener. Phone: bottom sheet.
- **Empty state**: in a card, left-aligned: title 17/600, one 14 muted line (max 360px), the action 20px under it.
  An empty list inside a card is the **inline** one: one 14 muted line, left-aligned, no well, no indent.
- **Ticks (v0.7), one drawing**: the select's check path, drawn as an SVG mask so it takes its
  surface's colour. **Checkbox**: 20px box, radius 8, 1.5px input line; checked = ink with an on-ink tick
  drawn in left to right; some = ink with a dash. **CheckRow**: box, title 14/500 (+ 12 hint), muted
  detail on the right; rows in `cp-checks` get hairlines. **DoneMark** (display only): a ring when to do,
  an ink ring for the one you're on, good with the on-ink tick when done (16 / 20 / 24). **TickList**:
  16px ink tick (good with `is-good`), not included = muted with a dash. Never ✅ emoji, never a native box.
- **Radios**: 20px ring, ink with an on-ink dot when picked; native, so the arrow keys work. **Option
  cards**: the input's 1px line, radius 14, padding 14 16; picked = well with a 2px ink edge.
- **Settings row**: label 14 ink + help 12 muted left, the control right (compact at the far right, or the
  inline field's 60% column with `wide`); rows 14px apart with a hairline. **Group label** over a group of
  rows: 12/500 muted, sentence case, never UPPERCASE; 20px above a following group.
- **SettingStrip**: a whole page's / section's on-off: a tile-padded card, title 14/600 + 13 muted line,
  a Toggle on the right (not an On/Off switch). **SaveBar**: an ink chip (radius 20) sticky 16px above
  the foot, Discard (text) + Save (inverse); toasts stack above it.
- **Disclosure**: native details/summary, 14/500 row ≥44px, muted meta, a 16px chevron on the right that
  turns over; `is-card` for its own card.
- **Small labels**: **Pill** status (radius 999, 12/600; `is-outline` for neutral on the stone,
  `has-dot`); **Tag** a category chip (radius 8, 12/500, well in a card, card on stone); **CountBadge**
  ink circle 20px with 12/600 number; **StatusDot** 8px dot + 13 word.
- **Buttons, disabled**: every filled kind becomes the well with muted words at full opacity (never a
  faded ink slab); a text button fades to half. Loading is not disabled: it keeps its look and breathes.
  Icon buttons: 36 / 32 / 28 (`xs`, toolbars and row handles).
- **Time / colour / picture**: TimePicker = the Select with a clock (a list `step` minutes apart);
  ColorField = a swatch button + the hex input, the picker a pop-up (square, hue, presets: the one place a
  gradient is allowed); ImageField = a 64 preview (round / 128×72 wide) + Upload or Replace / Remove, takes
  a dropped file. Never `type="time"`, `type="color"` or a bare file input.
- **Bars / funnels / ProgressBar**: track well (line on a well), radius 999, height 10 (thin 4); fill ink (or good for "beat usual"). Charts: bars radius `8px 8px 3px 3px`, winners good, rest `bar`, reference line 1.5px dashed `dash`.
- **Loading**: skeletons in the shape of the page: soft bars (radius 20, `--skeleton` at 30%) that pulse to 60% in small steps after a second, staggered 100ms; they read on stone, card and well. No spinners.

## Connections (v0.8) — the look, and the security contract

One page shape for every app's outside services (FounderOS's board, Macro's security, stricter than both).
React: `ConnectionsGrid` → `ConnectionCard`, `ConnectDialog`, `ConnectionDetail`. Plain HTML: the same
`cp-conn-*` markup plus `cp-connections.js` (logos, category pills, `<dialog>` open/close, the key field).

**The look.** "Connected (n)" first (needs reconnecting → needs a look → connected), then "Add a
connection" with category pills; a tile grid `minmax(280px, 1fr)` 12 apart, one column ≤860px. A card:
40px logo tile (well, radius 12; the logo monochrome, ink on light and light on dark; the initial when
there's none), name 14/600 with a Shared or Managed tag, purpose 13 muted, a StatusDot with words (never
colour alone), connected-as and "Checked 4 min ago" 12 muted, one button: Connect / Reconnect (ink) or
Manage. No borders, no shadows. Pop-ups are the 520 dialog (bottom sheet on a phone).

**Built-in logos** (simple-icons, CC0): airtable, anthropic, calendly, cloudflare, convex,
facebook, gemini, github, gmail, google, googlecalendar, googlesheets, instagram, kit, linear, meta,
notion, resend, stripe, supabase, tiktok, upstash, vercel, youtube, zoom. Found from `logo`, else the id,
else the name ("Google Calendar", "ConvertKit"). Cal.com (a wordmark, unreadable at 20px), Slack, Zernio, Tally, GoHighLevel, OpenAI,
Groq and Fathom Video aren't in the set: initial tile, or pass your own node.

**The contract.** An app may only use these components if its server keeps these rules:

1. **OAuth over pasted keys** wherever the provider has it. A pasted key is the fallback (`method: "key"`).
   A key Kevin sets in Doppler is `method: "managed"`: shown, never connectable from the page.
2. **Least access, listed first.** `ConnectDialog` requires `scopes` (what it will be able to do, plain
   words, provider scope underneath); add `never`. Ask again when a feature needs more.
3. **Secrets live on the server only**: Doppler for Kevin's keys; anything a user connects is stored
   encrypted (AES-256-GCM with a key from Doppler, or Supabase Vault), readable only from server code or
   an internal function, never from a public query.
4. **Never back to the browser.** The page gets status, `connectedAs`, dates and at most `last4`. The
   `Connection` type has no secret field and draws only the last four of `last4`. The key field is
   uncontrolled, has no reveal button, and is emptied before `onSubmitKey` runs: POST it once, don't put
   it in state, a URL, a log or an error message, and never echo it back in the response.
5. **OAuth done properly**: a one-time or HMAC-signed `state` with an expiry, checked timing-safe; PKCE
   where offered; fixed redirect URIs; the callback requires the signed-in user and their role.
6. **Disconnect is real**: revoke at the provider (Slack `auth.revoke`, Google `/revoke`, Kit and Notion
   `oauth/revoke`, Stripe Connect `deauthorize`, Meta permissions delete), delete any webhook we created,
   then delete the stored token. If the revoke fails, say so (`problem`) and keep a "revoke failed" row.
   For a pasted key the confirm says honestly that the key still works until it's deleted at the provider.
7. **Who and when**: store `connectedBy`, `connectedAt`, `lastUsedAt`, `lastCheckedAt`, `lastError`, and an
   activity log (connect / check / fail / disconnect) with no secret in it.
8. **Health is real**: `status` and `lastSync` come from a live call to the provider ("Check now"), not
   from "a key is saved"; refresh tokens rotate before they expire; a failure turns the card red with the
   reason and Reconnect.
9. **Shared vs this app's**: a shared one (Kit, Stripe, Gemini, Zernio) lives once (Doppler `shared/prd`
   or the portal), is tagged Shared with `usedBy`, and its disconnect warns which apps stop.
10. **Connect routes** are admin-only, rate-limited, accept only the key names the catalogue declares for
   that service (no newlines), and never log values.

```tsx
<ConnectionsGrid connections={rows} onConnect={setConnecting} onManage={setManaging} />
<ConnectDialog open={!!connecting} connection={connecting} appName="Sales Pages"
  scopes={connecting?.scopes ?? []} onClose={() => setConnecting(null)}
  onContinue={(c) => (location.href = `/api/connections/${c.id}/start`)}
  onSubmitKey={(c, key) => saveKey(c.id, key)} />
<ConnectionDetail open={!!managing} connection={managing} onClose={() => setManaging(null)}
  onSyncNow={check} onDisconnect={disconnect} consequence="Checkout stops taking payments." />
```

## Light and dark

- Follow the system by default. A switch at the foot of the sidebar cycles
  Auto → Light → Dark; the pick lives in `localStorage.theme` (shared, so the
  portal and the apps it frames agree). Dark is Kevin's favourite.
- Set the theme before first paint so the page never flashes:

  ```html
  <script>try{var t=localStorage.getItem('theme');if(t==='light'||t==='dark')document.documentElement.dataset.theme=t}catch(e){}</script>
  ```

- Charts read colours from CSS variables when they draw; redraw on theme change.

## Layout

- **Floating sidebar, no top bar.** The sidebar is a white card (radius 20)
  sitting on the stone with the page beside it, 24px from the edges, 20px gap.
  - Rows are pills (radius 999, ~32px) with a 16px line icon; the page you're
    on is an ink pill. Group labels 12/600 uppercase muted (or 12/500 sentence case, `labelStyle="plain"`, as the older apps had); 200px wide by default, 240 where an app had that. It is the shared
    `Sidebar` (`cp-side-*`), lifted from the portal.
  - Account at the top, theme switch and status at the foot.
  - Collapsed: a slim 64px icon strip (`cp-nav-closed` on `<html>`, `localStorage.nav`; the portal's old `nav-closed` class works too while an app migrates, see the package README); the hovered row grows out as an ink pill.
  - A new product area is a new group (Analytics, Ideas, DMs, Settings…), never a new top bar.
- **On a phone** the sidebar becomes a frosted header with every page as a
  swipeable pill row; 16px gutter; nothing scrolls sideways except that row.
- **Details open in a pop-up, not a side panel.** Phone: bottom sheet. Esc,
  backdrop or × closes; arrow keys step through a list.
- Main column order: header → tile row → the page's main content (pictures
  first) → secondary cards.

## Motion (appledesign skill)

- Respond on press: scale 0.97, instantly.
- One curve: `cubic-bezier(.2,.8,.2,1)`; things enter in ~200–280ms (content builds in with a short blur-up).
- Anything that enters leaves the same way. Honour `prefers-reduced-motion`.

## Where it is live

- **ContentOS** (DataOS dashboard): `dashboard/public/theme.css`, reference build.
- **Client portal**: coach-portal-demo (`portal-reel-look`, `coach-reel-look`).
- **DM OS** (DM Setter/openreply, `/os`): `app/(os)/os/os.css` tokens + `reel.css`.
